import assert from 'node:assert/strict';
import test from 'node:test';
import {
  ANTE_POINTS,
  STARTING_POINTS,
  applyHumanAction,
  compareHands,
  createDeck,
  createRound,
  evaluateHand,
  getActivePlayers,
  getChaalCost,
  getNextStake,
  getRaiseCost,
  getShowCost,
  playComputerTurn,
  revealHumanCards,
  shuffleDeck,
} from '../utils/teenPatti.ts';

const card = (rank, suit) => ({ rank, suit });
const hand = (...cards) => cards;

function seededRandom(seed) {
  let value = seed >>> 0;
  return () => {
    value = (1664525 * value + 1013904223) >>> 0;
    return value / 0x1_0000_0000;
  };
}

function makeShowState(humanCards, opponentCards, humanSeen = false, opponentSeen = false) {
  const state = createRound(STARTING_POINTS, 1, () => 0.5);
  const selectedCards = [...humanCards, ...opponentCards];
  const selectedKeys = new Set(selectedCards.map((item) => `${item.rank}:${item.suit}`));
  const remainingCards = createDeck().filter(
    (item) => !selectedKeys.has(`${item.rank}:${item.suit}`),
  );
  let cursor = 0;

  const players = state.players.map((player, index) => {
    if (index === 0) {
      return { ...player, cards: humanCards, seen: humanSeen, folded: false };
    }
    if (index === 1) {
      return { ...player, cards: opponentCards, seen: opponentSeen, folded: false };
    }
    const cards = remainingCards.slice(cursor, cursor + 3);
    cursor += 3;
    return { ...player, cards, folded: true };
  });

  return { ...state, players, currentTurnIndex: 0 };
}

test('a standard deck has 52 unique cards and every deal has 4 distinct three-card hands', () => {
  const deck = createDeck();
  assert.equal(deck.length, 52);
  assert.equal(new Set(deck.map((item) => `${item.rank}:${item.suit}`)).size, 52);

  for (let seed = 1; seed <= 250; seed += 1) {
    const state = createRound(STARTING_POINTS, seed, seededRandom(seed));
    const dealtCards = state.players.flatMap((player) => player.cards);
    assert.equal(state.players.every((player) => player.cards.length === 3), true);
    assert.equal(new Set(dealtCards.map((item) => `${item.rank}:${item.suit}`)).size, 12);
  }

  const shuffled = shuffleDeck(createDeck(), () => 0.5);
  const dealt = createRound(STARTING_POINTS, 1, () => 0.5);
  for (let playerIndex = 0; playerIndex < 4; playerIndex += 1) {
    assert.deepEqual(
      dealt.players[playerIndex]?.cards,
      [shuffled[playerIndex], shuffled[playerIndex + 4], shuffled[playerIndex + 8]],
    );
  }
});

test('hand rankings compare in order: trail, pure sequence, sequence, color, pair, high card', () => {
  const trail = hand(card(2, 'Spades'), card(2, 'Hearts'), card(2, 'Diamonds'));
  const pureSequence = hand(card(14, 'Spades'), card(13, 'Spades'), card(12, 'Spades'));
  const sequence = hand(card(10, 'Spades'), card(9, 'Hearts'), card(8, 'Clubs'));
  const color = hand(card(14, 'Clubs'), card(11, 'Clubs'), card(8, 'Clubs'));
  const pair = hand(card(14, 'Spades'), card(14, 'Hearts'), card(13, 'Clubs'));
  const highCard = hand(card(14, 'Spades'), card(11, 'Hearts'), card(8, 'Clubs'));

  assert.deepEqual(
    [trail, pureSequence, sequence, color, pair, highCard].map(
      (cards) => evaluateHand(cards).category,
    ),
    [6, 5, 4, 3, 2, 1],
  );
  for (let index = 0; index < 5; index += 1) {
    const hands = [trail, pureSequence, sequence, color, pair, highCard];
    assert.equal(compareHands(hands[index], hands[index + 1]), 1);
  }
});

test('rank tiebreaks cover trails, sequences, colors, pairs, high cards, and equal hands', () => {
  const tripleAces = hand(card(14, 'Spades'), card(14, 'Hearts'), card(14, 'Diamonds'));
  const tripleTwos = hand(card(2, 'Spades'), card(2, 'Hearts'), card(2, 'Diamonds'));
  const akq = hand(card(14, 'Spades'), card(13, 'Hearts'), card(12, 'Clubs'));
  const a23 = hand(card(14, 'Spades'), card(2, 'Hearts'), card(3, 'Clubs'));
  const kqj = hand(card(13, 'Spades'), card(12, 'Hearts'), card(11, 'Clubs'));
  const highSequence = hand(card(4, 'Spades'), card(3, 'Hearts'), card(2, 'Clubs'));
  const pairAcesKickerKing = hand(card(14, 'Spades'), card(14, 'Hearts'), card(13, 'Clubs'));
  const pairAcesKickerQueen = hand(card(14, 'Diamonds'), card(14, 'Clubs'), card(12, 'Hearts'));
  const pairKings = hand(card(13, 'Spades'), card(13, 'Hearts'), card(14, 'Clubs'));
  const flushAceHigh = hand(card(14, 'Spades'), card(10, 'Spades'), card(8, 'Spades'));
  const flushKingHigh = hand(card(13, 'Hearts'), card(12, 'Hearts'), card(9, 'Hearts'));
  const flushAceSecondTen = hand(card(14, 'Diamonds'), card(10, 'Diamonds'), card(8, 'Diamonds'));
  const flushAceSecondNine = hand(card(14, 'Clubs'), card(9, 'Clubs'), card(8, 'Clubs'));
  const highAceKingJack = hand(card(14, 'Spades'), card(13, 'Hearts'), card(11, 'Clubs'));
  const highAceKingTen = hand(card(14, 'Hearts'), card(13, 'Diamonds'), card(10, 'Clubs'));

  assert.equal(compareHands(tripleAces, tripleTwos), 1);
  assert.equal(compareHands(akq, a23), 1);
  assert.equal(compareHands(a23, kqj), 1);
  assert.equal(compareHands(kqj, highSequence), 1);
  assert.equal(compareHands(flushAceHigh, flushKingHigh), 1);
  assert.equal(compareHands(flushAceSecondTen, flushAceSecondNine), 1);
  assert.equal(compareHands(pairAcesKickerKing, pairAcesKickerQueen), 1);
  assert.equal(compareHands(pairAcesKickerQueen, pairKings), 1);
  assert.equal(compareHands(highAceKingJack, highAceKingTen), 1);

  const identicalByRank = hand(card(14, 'Spades'), card(13, 'Hearts'), card(12, 'Diamonds'));
  const sameRanksOtherSuits = hand(card(14, 'Clubs'), card(13, 'Diamonds'), card(12, 'Hearts'));
  assert.equal(compareHands(identicalByRank, sameRanksOtherSuits), 0);
});

test('invalid hand shapes and duplicate cards are rejected', () => {
  assert.throws(() => evaluateHand([card(14, 'Spades')]), /exactly three/);
  assert.throws(
    () => evaluateHand(hand(card(14, 'Spades'), card(14, 'Spades'), card(2, 'Clubs'))),
    /duplicate cards/,
  );
  assert.throws(
    () => evaluateHand(hand(card(1, 'Spades'), card(5, 'Hearts'), card(2, 'Clubs'))),
    /ranks 2 through Ace/,
  );
});

test('dealer and first actor rotate clockwise, with the next seat after the dealer acting first', () => {
  const expected = [
    ['you', 'bot-mira'],
    ['bot-mira', 'bot-dev'],
    ['bot-dev', 'bot-asha'],
    ['bot-asha', 'you'],
    ['you', 'bot-mira'],
  ];
  for (let round = 1; round <= expected.length; round += 1) {
    const state = createRound(STARTING_POINTS, round, () => 0.5);
    const dealer = state.players.find((player) => player.dealer);
    assert.deepEqual([dealer?.id, state.players[state.currentTurnIndex]?.id], expected[round - 1]);
    assert.equal(state.pot, ANTE_POINTS * 4);
    assert.equal(state.currentStake, 10);
  }
});

test('Chaal and Raise costs are incremental, seen costs are doubled, and stake is capped', () => {
  const state = createRound(STARTING_POINTS, 1, () => 0.5);
  const blind = state.players[0];
  const seen = { ...blind, seen: true };
  const seenOpponent = { ...state.players[1], seen: true };

  assert.equal(getChaalCost(blind, 10), 10);
  assert.equal(getChaalCost(seen, 10), 20);
  assert.equal(getRaiseCost(blind, 10), 20);
  assert.equal(getRaiseCost(seen, 10), 40);
  assert.equal(getNextStake(10), 20);
  assert.equal(getNextStake(20), 40);
  assert.equal(getNextStake(40), 40);
  assert.equal(getRaiseCost(blind, 40), null);
  assert.equal(getShowCost(blind, seenOpponent, 10), 10);
  assert.equal(getShowCost(seen, seenOpponent, 10), 20);
  assert.equal(getShowCost(seen, blind, 10), null);
});

test('every repeated Chaal costs points; a completed clockwise circuit cannot turn into free calls', () => {
  let state = createRound(STARTING_POINTS, 1, () => 0.5);
  assert.equal(state.currentTurnIndex, 1);
  for (let index = 0; index < 3; index += 1) {
    state = playComputerTurn(state, () => 0.999);
  }
  assert.equal(state.currentTurnIndex, 0);
  state = applyHumanAction(state, 'call');
  assert.equal(state.players[0].balance, 2_480);
  assert.equal(state.players[0].contribution, 10);

  for (let index = 0; index < 3; index += 1) {
    state = playComputerTurn(state, () => 0.999);
  }
  assert.equal(state.currentTurnIndex, 0);
  state = applyHumanAction(state, 'call');
  assert.equal(state.players[0].balance, 2_470);
  assert.equal(state.players[0].contribution, 20);
  assert.equal(state.pot, 120);
});

test('Raise pays the appropriate blind/seen amount and updates the stake to the next level', () => {
  let blindState = createRound(STARTING_POINTS, 1, () => 0.5);
  blindState = { ...blindState, currentTurnIndex: 0 };
  blindState = applyHumanAction(blindState, 'raise');
  assert.equal(blindState.currentStake, 20);
  assert.equal(blindState.players[0].balance, 2_470);
  assert.equal(blindState.pot, 60);

  let seenState = createRound(STARTING_POINTS, 1, () => 0.5);
  seenState = {
    ...seenState,
    currentTurnIndex: 0,
    players: seenState.players.map((player, index) =>
      index === 0 ? { ...player, seen: true } : player,
    ),
  };
  seenState = applyHumanAction(seenState, 'raise');
  assert.equal(seenState.currentStake, 20);
  assert.equal(seenState.players[0].balance, 2_450);
  assert.equal(seenState.pot, 80);

  const capped = { ...seenState, currentStake: 40, currentTurnIndex: 0 };
  assert.equal(applyHumanAction(capped, 'raise'), capped);
});

test('Show eligibility and cost follow blind/seen rules, and only the requester pays', () => {
  const highHand = hand(card(14, 'Spades'), card(14, 'Hearts'), card(14, 'Diamonds'));
  const lowHand = hand(card(13, 'Spades'), card(13, 'Hearts'), card(13, 'Diamonds'));

  const blindVsSeen = makeShowState(highHand, lowHand, false, true);
  const blindShow = applyHumanAction(blindVsSeen, 'show');
  assert.equal(blindShow.phase, 'round-over');
  assert.equal(blindShow.result?.potAwarded, 50);
  assert.equal(blindShow.pot, 0);
  assert.equal(blindShow.players[0].balance, 2_530);
  assert.equal(blindShow.players[1].balance, 2_490);
  assert.equal(blindShow.result?.netPoints, 30);

  const seenVsSeen = makeShowState(highHand, lowHand, true, true);
  const seenShow = applyHumanAction(seenVsSeen, 'show');
  assert.equal(seenShow.result?.potAwarded, 60);
  assert.equal(seenShow.players[0].balance, 2_530);
  assert.equal(seenShow.players[1].balance, 2_490);

  const seenVsBlind = makeShowState(highHand, lowHand, true, false);
  assert.equal(getShowCost(seenVsBlind.players[0], seenVsBlind.players[1], 10), null);
  assert.equal(applyHumanAction(seenVsBlind, 'show'), seenVsBlind);
});

test('Showdown awards the pot to the better hand; exact ties go to the non-requester', () => {
  const pair = hand(card(13, 'Spades'), card(13, 'Hearts'), card(2, 'Clubs'));
  const highCard = hand(card(14, 'Spades'), card(12, 'Hearts'), card(8, 'Clubs'));
  const losingState = makeShowState(highCard, pair);
  const loss = applyHumanAction(losingState, 'show');
  assert.deepEqual(loss.result?.winnerIds, ['bot-mira']);
  assert.equal(loss.result?.potAwarded, 50);
  assert.equal(loss.result?.netPoints, -20);
  assert.equal(loss.pot, 0);
  assert.equal(
    loss.players.reduce((total, player) => total + player.balance, 0),
    10_000,
  );

  const tiedHand = hand(card(14, 'Spades'), card(13, 'Hearts'), card(12, 'Diamonds'));
  const equalHandOtherSuits = hand(card(14, 'Clubs'), card(13, 'Diamonds'), card(12, 'Hearts'));
  const tiedState = makeShowState(tiedHand, equalHandOtherSuits);
  const tie = applyHumanAction(tiedState, 'show');
  assert.deepEqual(tie.result?.winnerIds, ['bot-mira']);
  assert.match(tie.message, /player who requested the show loses/);
  assert.equal(tie.result?.potAwarded, 50);
  assert.equal(tie.pot, 0);
});

test('Pack settles the pot to the last active player, and folded players cannot reveal later', () => {
  let state = createRound(STARTING_POINTS, 1, () => 0.5);
  state = { ...state, currentTurnIndex: 0 };
  state = applyHumanAction(state, 'fold');
  const foldedState = state;
  assert.equal(revealHumanCards(state), foldedState);

  while (state.phase === 'playing') {
    state = playComputerTurn(state, () => 0);
  }
  assert.equal(state.result?.potAwarded, 40);
  assert.equal(state.pot, 0);
  assert.equal(state.result?.winnerIds.length, 1);
  assert.equal(getActivePlayers(state).length, 1);
  assert.equal(
    state.players.reduce((total, player) => total + player.balance, 0),
    10_000,
  );
});

test('ante refill is free virtual credit; unaffordable Chaal is rejected and Pack remains available', () => {
  const exactAnte = createRound(ANTE_POINTS, 1, () => 0.5);
  assert.equal(exactAnte.pointsRefilled, false);
  assert.equal(exactAnte.players[0].balance, 0);
  const unableToCall = { ...exactAnte, currentTurnIndex: 0 };
  assert.equal(applyHumanAction(unableToCall, 'call'), unableToCall);
  const packed = applyHumanAction(unableToCall, 'fold');
  assert.equal(packed.players[0].folded, true);

  const refill = createRound(ANTE_POINTS - 1, 2, () => 0.5);
  assert.equal(refill.pointsRefilled, true);
  assert.equal(refill.startingBalance, STARTING_POINTS);
  assert.equal(refill.players[0].balance, STARTING_POINTS - ANTE_POINTS);
});

test('100 complete seeded rounds terminate with one winner and conserve virtual points', () => {
  for (let seed = 1; seed <= 100; seed += 1) {
    const random = seededRandom(seed);
    let state = createRound(STARTING_POINTS, seed, random);
    const initialTotal = state.players.reduce((total, player) => total + player.balance, state.pot);
    let steps = 0;

    while (state.phase === 'playing' && steps < 1_200) {
      const player = state.players[state.currentTurnIndex];
      assert.ok(player, `seed ${seed}: current turn must point to a player`);
      assert.equal(player.folded, false, `seed ${seed}: folded player cannot act`);

      if (player.isHuman) {
        if (!player.seen && random() < 0.12) state = revealHumanCards(state);
        const active = getActivePlayers(state);
        const opponent = active.find((candidate) => candidate.id !== player.id);
        const showCost =
          active.length === 2 && opponent
            ? getShowCost(player, opponent, state.currentStake)
            : null;
        const raiseCost = getRaiseCost(player, state.currentStake);
        const callCost = getChaalCost(player, state.currentStake);
        const roll = random();
        const action =
          showCost !== null && showCost <= player.balance && roll < 0.1
            ? 'show'
            : raiseCost !== null && raiseCost <= player.balance && roll < 0.28
              ? 'raise'
              : callCost <= player.balance
                ? 'call'
                : 'fold';
        state = applyHumanAction(state, action);
      } else {
        state = playComputerTurn(state, random);
      }

      assert.ok(state.players.every((candidate) => candidate.balance >= 0));
      assert.ok(state.pot >= 0);
      steps += 1;
    }

    assert.equal(state.phase, 'round-over', `seed ${seed} did not finish in ${steps} actions`);
    assert.equal(state.result?.winnerIds.length, 1);
    assert.equal(state.pot, 0);
    assert.equal(
      state.players.reduce((total, player) => total + player.balance, 0),
      initialTotal,
      `seed ${seed}: points must be conserved through settlement`,
    );
  }
});
