import assert from 'node:assert/strict';
import test from 'node:test';
import {
  cardPointValue,
  createNextRummyRound,
  createRummyDeck,
  createRummyGame,
  discardForHuman,
  drawForHuman,
  getBestDiscard,
  isWildCard,
  playComputerTurn,
  scoreRummyHand,
  selectRummyDiscard,
  validateRummyHand,
} from '../utils/rummy.ts';

function seededRandom(seed) {
  let value = seed >>> 0;
  return () => {
    value = (1664525 * value + 1013904223) >>> 0;
    return value / 0x1_0000_0000;
  };
}

const deck = createRummyDeck();
const card = (rank, suit, copy = 0) =>
  deck.find((item) => item.rank === rank && item.suit === suit && item.deck === copy);
const joker = deck.find((item) => item.printedJoker);

function validHand(sequence = [card(7, 'Spades'), card(8, 'Spades'), card(9, 'Spades')]) {
  return [
    ...sequence,
    card(4, 'Hearts'),
    card(5, 'Hearts'),
    card(6, 'Hearts'),
    card(10, 'Spades'),
    card(10, 'Hearts'),
    card(10, 'Diamonds'),
    card(10, 'Clubs'),
    card(11, 'Spades'),
    card(11, 'Hearts'),
    card(11, 'Diamonds'),
  ];
}

function invalidNoPureHand() {
  return [
    card(4, 'Spades'),
    card(5, 'Spades'),
    joker,
    card(8, 'Hearts'),
    card(9, 'Hearts'),
    card(7, 'Clubs'),
    card(2, 'Spades'),
    card(2, 'Hearts'),
    card(2, 'Diamonds'),
    card(11, 'Spades'),
    card(11, 'Hearts'),
    card(11, 'Diamonds'),
    card(13, 'Clubs'),
  ];
}

function replaceHumanHand(state, hand, drawnCardId) {
  const ids = new Set(hand.map((item) => item.id));
  const players = state.players.map((player, index) => ({
    ...player,
    hand: index === 0 ? hand : player.hand.filter((item) => !ids.has(item.id)),
  }));
  return {
    ...state,
    players,
    drawPile: state.drawPile.filter((item) => !ids.has(item.id)),
    discardPile: state.discardPile.filter((item) => !ids.has(item.id)),
    currentPlayerIndex: 0,
    phase: 'discard',
    drawnCardId,
    drawnFrom: 'stock',
    selectedDiscardId: drawnCardId,
    result: null,
  };
}

test('the 106-card double deck has two jokers and deals 13 distinct cards to 2–4 players', () => {
  const fullDeck = createRummyDeck();
  assert.equal(fullDeck.length, 106);
  assert.equal(new Set(fullDeck.map((item) => item.id)).size, 106);
  assert.equal(fullDeck.filter((item) => item.printedJoker).length, 2);

  for (let playerCount = 2; playerCount <= 4; playerCount += 1) {
    const game = createRummyGame(playerCount, seededRandom(playerCount));
    assert.equal(game.players.length, playerCount);
    assert.ok(game.players.every((player) => player.hand.length === 13));
    assert.equal(game.currentPlayerIndex, 0);
    assert.equal(game.phase, 'draw');
    const allCards = [
      ...game.players.flatMap((player) => player.hand),
      ...game.drawPile,
      ...game.discardPile,
      game.wildMarker,
    ];
    assert.equal(allCards.length, 106);
    assert.equal(new Set(allCards.map((item) => item.id)).size, 106);
  }
  assert.throws(() => createRummyGame(1), /2 to 4/);
  assert.throws(() => createRummyGame(5), /2 to 4/);
});

test('declaration accepts two sequences including a pure sequence and complete non-overlapping groups', () => {
  const hand = validHand();
  assert.equal(hand.length, 13);
  const validation = validateRummyHand(hand, 7);
  assert.equal(validation.valid, true);
  assert.equal(validation.groups.filter((group) => group.kind === 'sequence').length, 2);
  assert.equal(validation.groups.some((group) => group.kind === 'sequence' && group.pure), true);
  assert.equal(validation.groups.flatMap((group) => group.cards).length, 13);
});

test('wild cards may substitute in an impure run while a wild-rank card used naturally is pure', () => {
  const hand = validHand([
    card(7, 'Spades'),
    card(8, 'Spades'),
    card(9, 'Spades'),
  ]);
  const validation = validateRummyHand(hand, 7);
  assert.equal(validation.valid, true);
  assert.equal(validation.groups.some((group) => group.kind === 'sequence' && group.pure), true);
  assert.equal(isWildCard(card(7, 'Spades'), 7), true);
  assert.equal(cardPointValue(card(7, 'Spades'), 7), 0);

  const substituteHand = [
    card(7, 'Spades'),
    card(8, 'Spades'),
    card(9, 'Spades'),
    card(4, 'Hearts'),
    card(5, 'Hearts'),
    joker,
    card(10, 'Spades'),
    card(10, 'Hearts'),
    card(10, 'Diamonds'),
    card(10, 'Clubs'),
    card(11, 'Spades'),
    card(11, 'Hearts'),
    card(11, 'Diamonds'),
  ];
  const substituted = validateRummyHand(substituteHand, 7);
  assert.equal(substituted.valid, true);
  assert.equal(
    substituted.groups.some((group) => group.kind === 'sequence' && !group.pure),
    true,
  );
});

test('declarations reject missing pure sequence, invalid wraparound, repeated cards, and incomplete hands', () => {
  const noPure = validateRummyHand(invalidNoPureHand(), 7);
  assert.equal(noPure.valid, false);
  assert.match(noPure.reason, /pure sequence/i);

  const wraparound = validHand([
    card(13, 'Spades'),
    card(14, 'Spades'),
    card(2, 'Spades'),
  ]);
  assert.equal(validateRummyHand(wraparound, 7).valid, false);

  const duplicate = validHand();
  duplicate[12] = duplicate[0];
  assert.equal(validateRummyHand(duplicate, 7).valid, false);
  assert.equal(validateRummyHand(validHand().slice(0, 12), 7).valid, false);

  const aceLow = validHand([card(14, 'Spades'), card(2, 'Spades'), card(3, 'Spades')]);
  const aceHigh = validHand([card(12, 'Spades'), card(13, 'Spades'), card(14, 'Spades')]);
  assert.equal(validateRummyHand(aceLow, 7).valid, true);
  assert.equal(validateRummyHand(aceHigh, 7).valid, true);
});

test('sets require three or four different suits, and same-suit duplicate copies cannot form one set', () => {
  const badSetHand = validHand([
    card(2, 'Spades'),
    card(3, 'Spades'),
    card(4, 'Spades'),
  ]);
  badSetHand[9] = card(10, 'Spades', 1);
  assert.equal(validateRummyHand(badSetHand, 7).valid, false);
});

test('penalty values use face values, wild cards score zero, and missing a pure life counts the hand up to 80', () => {
  assert.deepEqual(
    [card(2, 'Clubs'), card(9, 'Clubs'), card(10, 'Clubs'), card(11, 'Clubs'), card(12, 'Clubs'), card(13, 'Clubs'), card(14, 'Clubs')]
      .map((item) => cardPointValue(item, 7)),
    [2, 9, 10, 10, 10, 10, 10],
  );
  assert.equal(cardPointValue(joker, 7), 0);
  assert.equal(cardPointValue(card(7, 'Hearts'), 7), 0);

  const faceCardsOnly = [
    ...[11, 13, 14].flatMap((rank) =>
      ['Spades', 'Hearts', 'Diamonds', 'Clubs'].map((suit) => card(rank, suit)),
    ),
    card(11, 'Spades', 1),
  ];
  assert.equal(faceCardsOnly.length, 13);
  const score = scoreRummyHand(faceCardsOnly, 2);
  assert.equal(score.hasPureSequence, false);
  assert.equal(score.penalty, 80);
});

test('round scoring minimizes deadwood when both sequence requirements are met', () => {
  const hand = [
    card(2, 'Spades'),
    card(3, 'Spades'),
    card(4, 'Spades'),
    card(5, 'Hearts'),
    card(6, 'Hearts'),
    card(7, 'Hearts'),
    card(8, 'Spades'),
    card(8, 'Hearts'),
    card(8, 'Diamonds'),
    card(10, 'Spades'),
    card(10, 'Hearts'),
    card(10, 'Diamonds'),
    card(14, 'Clubs'),
  ];
  const score = scoreRummyHand(hand, 7);
  assert.equal(score.hasPureSequence, true);
  assert.equal(score.hasTwoSequences, true);
  assert.equal(score.penalty, 10);
});

test('best discard can identify a valid show and respects the just-taken discard restriction', () => {
  const hand = [...validHand(), card(2, 'Clubs')];
  const choice = getBestDiscard(hand, 7);
  assert.ok(choice);
  assert.equal(choice.cardId, card(2, 'Clubs').id);
  assert.equal(choice.canDeclare, true);

  const restricted = getBestDiscard(hand, 7, card(2, 'Clubs').id);
  assert.ok(restricted);
  assert.notEqual(restricted.cardId, card(2, 'Clubs').id);
});

test('drawing, selecting, discarding, and refusing to discard the just-taken open card follow turn rules', () => {
  const initial = createRummyGame(2, seededRandom(10));
  const openDraw = drawForHuman(initial, 'discard', seededRandom(11));
  assert.equal(openDraw.phase, 'discard');
  assert.equal(openDraw.players[0].hand.length, 14);
  assert.equal(openDraw.drawnFrom, 'discard');

  const rejected = discardForHuman(openDraw, false, openDraw.drawnCardId);
  assert.equal(rejected.phase, 'discard');
  assert.equal(rejected.players[0].hand.length, 14);
  assert.match(rejected.message, /cannot discard/i);

  const otherCard = openDraw.players[0].hand.find((item) => item.id !== openDraw.drawnCardId);
  assert.ok(otherCard);
  const selected = selectRummyDiscard(openDraw, otherCard.id);
  const afterDiscard = discardForHuman(selected, false);
  assert.equal(afterDiscard.phase, 'draw');
  assert.equal(afterDiscard.currentPlayerIndex, 1);
  assert.equal(afterDiscard.players[0].hand.length, 13);
  assert.equal(afterDiscard.discardPile.at(-1).id, otherCard.id);

  const stockDraw = drawForHuman(initial, 'stock', seededRandom(12));
  assert.equal(stockDraw.phase, 'discard');
  assert.equal(stockDraw.players[0].hand.length, 14);
});

test('invalid declarations are rejected; valid declarations settle winner and virtual match penalties', () => {
  const invalidHand = [...invalidNoPureHand(), card(2, 'Clubs')];
  let state = replaceHumanHand(createRummyGame(2, seededRandom(14)), invalidHand, card(2, 'Clubs').id);
  const invalidResult = discardForHuman(state, true);
  assert.equal(invalidResult.phase, 'discard');
  assert.equal(invalidResult.players[0].hand.length, 14);
  assert.match(invalidResult.message, /pure sequence/i);

  const winningHand = [...validHand(), card(2, 'Clubs')];
  state = replaceHumanHand(createRummyGame(2, seededRandom(15)), winningHand, card(2, 'Clubs').id);
  const result = discardForHuman(state, true);
  assert.equal(result.phase, 'round-over');
  assert.equal(result.result.winnerId, 'you');
  assert.equal(result.result.scores[0].roundPenalty, 0);
  assert.equal(result.players[0].totalPenalty, 0);
  assert.equal(result.result.winningGroups.flatMap((group) => group.cards).length, 13);

  const opponent = result.players.find((player) => player.id === 'bot-1');
  const opponentScore = result.result.scores.find((score) => score.playerId === 'bot-1');
  assert.ok(opponent);
  assert.ok(opponentScore);
  assert.equal(opponentScore.roundPenalty, scoreRummyHand(opponent.hand, result.wildRank).penalty);
  assert.equal(opponent.totalPenalty, opponentScore.roundPenalty);

  const nextRound = createNextRummyRound(result, seededRandom(16));
  assert.equal(nextRound.roundNumber, result.roundNumber + 1);
  assert.equal(nextRound.players[1].totalPenalty, result.players[1].totalPenalty);
  assert.equal(nextRound.players[0].hand.length, 13);
});

test('computer opponents take a legal turn and preserve hand size and turn order', () => {
  const game = createRummyGame(2, seededRandom(20));
  const botTurn = { ...game, currentPlayerIndex: 1 };
  const after = playComputerTurn(botTurn, seededRandom(21));
  assert.ok(after.phase === 'draw' || after.phase === 'round-over');
  assert.equal(after.players[1].hand.length, 13);
  if (after.phase === 'draw') {
    assert.equal(after.currentPlayerIndex, 0);
    assert.equal(after.players[0].hand.length, 13);
  } else {
    assert.equal(after.result.winnerId, 'bot-1');
  }
});

test('seeded single-player matches complete with legal draws, discards, and valid declarations', () => {
  for (let seed = 1; seed <= 12; seed += 1) {
    const random = seededRandom(seed * 179);
    let game = createRummyGame(4, random);
    let turns = 0;
    while (game.phase !== 'round-over' && turns < 1800) {
      const player = game.players[game.currentPlayerIndex];
      if (game.phase === 'draw' && player?.isHuman) {
        const source = game.discardPile.length > 0 && random() < 0.25 ? 'discard' : 'stock';
        game = drawForHuman(game, source, random);
      } else if (game.phase === 'discard' && player?.isHuman) {
        const choice = getBestDiscard(
          player.hand,
          game.wildRank,
          game.drawnFrom === 'discard' ? game.drawnCardId : null,
        );
        assert.ok(choice);
        game = discardForHuman(game, choice.canDeclare, choice.cardId);
      } else {
        game = playComputerTurn(game, random);
      }
      turns += 1;
    }
    assert.equal(game.phase, 'round-over', `seed ${seed} did not finish after ${turns} actions`);
    assert.ok(game.result);
    const winner = game.players.find((player) => player.id === game.result.winnerId);
    assert.ok(winner);
    assert.equal(validateRummyHand(winner.hand, game.wildRank).valid, true);
    assert.ok(game.result.scores.every((score) => score.roundPenalty >= 0 && score.roundPenalty <= 80));
    assert.ok(game.players.every((player) => player.hand.length === 13));
  }
});

