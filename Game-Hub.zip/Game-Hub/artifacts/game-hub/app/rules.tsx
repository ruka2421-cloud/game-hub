import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

const handRankings = [
  { rank: '01', name: 'Trail / Three of a Kind', example: 'A-A-A' },
  { rank: '02', name: 'Pure Sequence', example: 'A♠ K♠ Q♠' },
  { rank: '03', name: 'Sequence', example: '8♠ 7♥ 6♦' },
  { rank: '04', name: 'Color / Flush', example: 'A♦ J♦ 8♦' },
  { rank: '05', name: 'Pair', example: 'K♣ K♥ 5♦' },
  { rank: '06', name: 'High Card', example: 'A♣ J♥ 8♠' },
];

const howToPlay = [
  {
    icon: 'layers' as const,
    title: 'The deal',
    body: 'You and three computer players receive three cards each face down, dealt one at a time clockwise from a standard 52-card deck. Everyone adds 10 virtual points to the pot. The dealer moves one seat each round; the player to the dealer’s left acts first.',
  },
  {
    icon: 'eye' as const,
    title: 'Blind or seen',
    body: 'Keep your cards hidden to play blind, or look at them for free to play seen. Each Chaal adds points to the pot: blind costs the current stake; seen costs twice the current stake.',
  },
  {
    icon: 'repeat' as const,
    title: 'Take your turn',
    body: 'Choose Chaal to add the blind or seen amount, Raise to move the stake to its next level (10 → 20 → 40), or Pack to fold. A blind raise costs the new stake; a seen raise costs twice the new stake. Points already added stay in the pot.',
  },
  {
    icon: 'award' as const,
    title: 'Showdown',
    body: 'With two players left, a blind player may request Show for the current stake. A seen player may request it only against another seen player, for twice the stake. Only the requester pays. The higher hand wins; if hands tie, the player who did not request Show wins. If everyone else packs, the last player wins the pot.',
  },
];

export default function RulesScreen() {
  const colors = useColors();

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.safeArea,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === 'web' ? 67 : 0,
        },
      ]}
    >
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === 'web' ? 34 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Pressable
          accessibilityRole="button"
          onPress={() => router.back()}
          style={({ pressed }) => [
            styles.backButton,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              opacity: pressed ? 0.75 : 1,
            },
          ]}
          testID="rules-back"
        >
          <Feather name="arrow-left" size={18} color={colors.foreground} />
          <Text style={[styles.backText, { color: colors.foreground }]}>Back to table</Text>
        </Pressable>

        <Text style={[styles.eyebrow, { color: colors.primary }]}>TEEN PATTI</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>How to play</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          A quick guide to turns, hand rankings, and virtual-point scoring.
        </Text>

        <View style={styles.ruleList}>
          {howToPlay.map((rule, index) => (
            <View
              key={rule.title}
              style={[
                styles.ruleCard,
                { backgroundColor: colors.card, borderColor: colors.border },
              ]}
            >
              <View style={[styles.ruleNumber, { backgroundColor: colors.accent }]}>
                <Text style={[styles.ruleNumberText, { color: colors.goldSoft }]}>
                  0{index + 1}
                </Text>
              </View>
              <View style={styles.ruleCopy}>
                <Text style={[styles.ruleTitle, { color: colors.foreground }]}>
                  {rule.title}
                </Text>
                <Text style={[styles.ruleBody, { color: colors.mutedForeground }]}>
                  {rule.body}
                </Text>
              </View>
              <Feather name={rule.icon} size={16} color={colors.primary} />
            </View>
          ))}
        </View>

        <View style={styles.rankHeader}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Hand rankings
            </Text>
            <Text style={[styles.sectionCaption, { color: colors.mutedForeground }]}>
              Strongest to weakest
            </Text>
          </View>
          <Feather name="bar-chart-2" size={17} color={colors.primary} />
        </View>

        <View style={[styles.rankTable, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {handRankings.map((hand, index) => (
            <View
              key={hand.rank}
              style={[
                styles.rankRow,
                index > 0 && { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
              ]}
            >
              <Text style={[styles.rankNumber, { color: colors.goldSoft }]}>{hand.rank}</Text>
              <View style={styles.rankNameWrap}>
                <Text style={[styles.rankName, { color: colors.foreground }]}>{hand.name}</Text>
                <Text style={[styles.rankExample, { color: colors.mutedForeground }]}>{hand.example}</Text>
              </View>
            </View>
          ))}
        </View>
        <Text style={[styles.tieNote, { color: colors.mutedForeground }]}>
          Sequences rank A-K-Q, then A-2-3, then K-Q-J here; some tables order A-2-3 differently. Compare pairs by pair rank then kicker, and colors/high cards from highest card down. Suits do not break ties; in a tied Show, the requester loses.
        </Text>

        <View style={[styles.scoringCard, { backgroundColor: colors.heroStart }]}>
          <Feather name="circle" size={19} color={colors.goldSoft} />
          <View style={styles.scoringCopy}>
            <Text style={[styles.scoringTitle, { color: colors.cream }]}>
              Practice points only
            </Text>
            <Text style={[styles.scoringBody, { color: colors.mutedForeground }]}>
              The winner receives the virtual-point pot. If your balance falls below the 10-point ante, a free 2,500-point practice balance is restored for your next round. Points have no cash value.
            </Text>
          </View>
        </View>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.back()}
          style={({ pressed }) => [
            styles.returnButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
          ]}
          testID="rules-return-to-game"
        >
          <Feather name="arrow-left" size={15} color={colors.primaryForeground} />
          <Text style={[styles.returnButtonText, { color: colors.primaryForeground }]}>
            Return to game
          </Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 10 },
  backButton: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 12,
    minHeight: 40,
    marginBottom: 21,
  },
  backText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  eyebrow: { fontSize: 9, letterSpacing: 1.2, fontFamily: 'Inter_700Bold', marginBottom: 7 },
  title: { fontSize: 27, fontFamily: 'Inter_700Bold', letterSpacing: -0.8 },
  subtitle: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 6, lineHeight: 18 },
  ruleList: { gap: 9, marginTop: 19 },
  ruleCard: {
    borderWidth: 1,
    borderRadius: 15,
    padding: 11,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 9,
  },
  ruleNumber: { width: 31, height: 31, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  ruleNumberText: { fontSize: 9, fontFamily: 'Inter_700Bold' },
  ruleCopy: { flex: 1, gap: 4 },
  ruleTitle: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  ruleBody: { fontSize: 9, fontFamily: 'Inter_400Regular', lineHeight: 14 },
  rankHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 22, marginBottom: 9 },
  sectionTitle: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  sectionCaption: { fontSize: 9, fontFamily: 'Inter_400Regular', marginTop: 3 },
  rankTable: { borderWidth: 1, borderRadius: 15, overflow: 'hidden' },
  rankRow: { minHeight: 48, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 11 },
  rankNumber: { width: 24, fontSize: 10, fontFamily: 'Inter_700Bold' },
  rankNameWrap: { flex: 1, gap: 3 },
  rankName: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  rankExample: { fontSize: 8, fontFamily: 'Inter_400Regular' },
  tieNote: { fontSize: 9, fontFamily: 'Inter_400Regular', lineHeight: 14, marginTop: 8 },
  scoringCard: { flexDirection: 'row', alignItems: 'flex-start', gap: 11, padding: 14, borderRadius: 15, marginTop: 18 },
  scoringCopy: { flex: 1, gap: 5 },
  scoringTitle: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  scoringBody: { fontSize: 9, fontFamily: 'Inter_400Regular', lineHeight: 14 },
  returnButton: { minHeight: 43, borderRadius: 13, marginTop: 12, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  returnButtonText: { fontSize: 10, fontFamily: 'Inter_700Bold' },
});
