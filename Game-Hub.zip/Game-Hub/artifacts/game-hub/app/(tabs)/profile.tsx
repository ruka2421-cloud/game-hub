import { Feather } from '@expo/vector-icons';
import React from 'react';
import { Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useVirtualPoints } from '@/context/VirtualPointsContext';

export default function ProfileScreen() {
  const colors = useColors();
  const { balance, isLoaded } = useVirtualPoints();

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.safeArea,
        { backgroundColor: colors.background, paddingTop: Platform.OS === 'web' ? 67 : 0 },
      ]}
    >
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>YOUR CORNER</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Player profile</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Your Game Hub player card.
        </Text>

        <View style={[styles.profileCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.avatar, { backgroundColor: colors.accent }]}>
            <Feather name="user" size={31} color={colors.primary} />
          </View>
          <Text style={[styles.playerName, { color: colors.foreground }]}>Guest player</Text>
          <View style={[styles.guestTag, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.guestText, { color: colors.goldSoft }]}>CASUAL PLAYER</Text>
          </View>
          <Text style={[styles.profileDescription, { color: colors.mutedForeground }]}>
            A relaxed place to enjoy classic games with virtual points.
          </Text>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>At a glance</Text>
        <View style={[styles.statRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.statIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="circle" size={16} color={colors.primary} />
          </View>
          <Text style={[styles.statLabel, { color: colors.foreground }]}>Practice points</Text>
          <Text style={[styles.statValue, { color: colors.goldSoft }]}>
            {isLoaded ? balance.toLocaleString('en-IN') : '···'}
          </Text>
        </View>
        <View style={[styles.statRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.statIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="layers" size={16} color={colors.success} />
          </View>
          <Text style={[styles.statLabel, { color: colors.foreground }]}>Available games</Text>
          <Text style={[styles.statValue, { color: colors.goldSoft }]}>1</Text>
        </View>
        <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
          Profile details are shown on this device in this first version.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 22, paddingTop: 23, paddingBottom: Platform.OS === 'web' ? 34 : 28, gap: 13 },
  eyebrow: { fontSize: 10, letterSpacing: 1.2, fontFamily: 'Inter_700Bold', marginBottom: -8 },
  title: { fontSize: 28, fontFamily: 'Inter_700Bold', letterSpacing: -0.8 },
  subtitle: { fontSize: 13, fontFamily: 'Inter_400Regular', lineHeight: 19, marginTop: -7 },
  profileCard: { marginTop: 9, borderWidth: 1, borderRadius: 22, alignItems: 'center', padding: 22 },
  avatar: { width: 76, height: 76, borderRadius: 27, alignItems: 'center', justifyContent: 'center', marginBottom: 13 },
  playerName: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  guestTag: { borderRadius: 20, paddingHorizontal: 10, paddingVertical: 6, marginTop: 9 },
  guestText: { fontSize: 9, letterSpacing: 0.9, fontFamily: 'Inter_700Bold' },
  profileDescription: { textAlign: 'center', fontSize: 11, fontFamily: 'Inter_400Regular', lineHeight: 17, marginTop: 13, maxWidth: 260 },
  sectionTitle: { fontSize: 15, fontFamily: 'Inter_700Bold', marginTop: 7, marginBottom: -3 },
  statRow: { minHeight: 56, borderWidth: 1, borderRadius: 15, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  statIcon: { width: 32, height: 32, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  statLabel: { flex: 1, fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  statValue: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  disclaimer: { fontSize: 10, fontFamily: 'Inter_400Regular', lineHeight: 15, marginTop: 2 },
});
