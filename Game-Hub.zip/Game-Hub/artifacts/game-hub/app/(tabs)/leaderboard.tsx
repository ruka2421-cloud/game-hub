import { Feather } from '@expo/vector-icons';
import React from 'react';
import { Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export default function LeaderboardScreen() {
  const colors = useColors();

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.safeArea,
        { backgroundColor: colors.background, paddingTop: Platform.OS === 'web' ? 67 : 0 },
      ]}
    >
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>THE COMMUNITY</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Leaderboard</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          A friendly place to celebrate great games.
        </Text>

        <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.iconCircle, { backgroundColor: colors.accent }]}>
            <Feather name="bar-chart-2" size={27} color={colors.primary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Single-player for now</Text>
          <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
            Teen Patti is played against computer opponents. Your round result and virtual points appear in the game; shared rankings are not part of this version.
          </Text>
        </View>

        <View style={[styles.note, { backgroundColor: colors.secondary }]}>
          <Feather name="shield" size={16} color={colors.success} />
          <Text style={[styles.noteText, { color: colors.secondaryForeground }]}>
            Rankings use virtual practice points only.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 22, paddingTop: 23, paddingBottom: Platform.OS === 'web' ? 34 : 28 },
  eyebrow: { fontSize: 10, letterSpacing: 1.2, fontFamily: 'Inter_700Bold', marginBottom: 8 },
  title: { fontSize: 28, fontFamily: 'Inter_700Bold', letterSpacing: -0.8 },
  subtitle: { fontSize: 13, fontFamily: 'Inter_400Regular', marginTop: 7, lineHeight: 19 },
  emptyCard: { marginTop: 28, minHeight: 240, borderRadius: 22, borderWidth: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  iconCircle: { width: 62, height: 62, borderRadius: 21, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  emptyBody: { fontSize: 12, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 18, marginTop: 8, maxWidth: 270 },
  note: { marginTop: 16, padding: 14, borderRadius: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  noteText: { flex: 1, fontSize: 11, fontFamily: 'Inter_500Medium', lineHeight: 16 },
});
