import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import React from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useVirtualPoints } from '@/context/VirtualPointsContext';

const games = [
  { name: 'Rummy', icon: 'copy' as const, available: true },
  { name: 'Dice Games', icon: 'target' as const },
  { name: 'Poker Style', icon: 'layers' as const },
  { name: 'Casino Style', icon: 'sun' as const },
  { name: 'Traditional Games', icon: 'globe' as const },
];

function feedback() {
  void Haptics.selectionAsync();
}

export default function HomeScreen() {
  const colors = useColors();
  const { balance, isLoaded } = useVirtualPoints();

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.safeArea,
        { backgroundColor: colors.background, paddingTop: Platform.OS === 'web' ? 67 : 0 },
      ]}
    >
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === 'web' ? 34 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topBar}>
          <View style={styles.brand}>
            <View style={[styles.brandMark, { backgroundColor: colors.accent }]}>
              <Feather name="layers" size={19} color={colors.primary} />
            </View>
            <View>
              <Text style={[styles.brandTitle, { color: colors.foreground }]}>
                GAME HUB
              </Text>
              <Text style={[styles.brandCaption, { color: colors.mutedForeground }]}>
                GOOD GAMES, JUST FOR FUN
              </Text>
            </View>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Open virtual points"
            onPress={() => {
              feedback();
              router.push('/points');
            }}
            style={({ pressed }) => [
              styles.pointsPill,
              {
                borderColor: colors.border,
                backgroundColor: colors.card,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
            testID="home-points-button"
          >
            <Feather name="circle" size={14} color={colors.primary} />
            <Text style={[styles.pointsPillText, { color: colors.foreground }]}>
              {isLoaded ? balance.toLocaleString('en-IN') : '···'}
            </Text>
          </Pressable>
        </View>

        <LinearGradient
          colors={[colors.heroStart, colors.heroEnd]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.hero}
        >
          <View style={styles.heroCopy}>
            <View style={[styles.availableTag, { backgroundColor: colors.accent }]}>
              <View style={[styles.statusDot, { backgroundColor: colors.success }]} />
              <Text style={[styles.availableText, { color: colors.goldSoft }]}>
                TEEN PATTI · AVAILABLE
              </Text>
            </View>
            <Text style={[styles.heroTitle, { color: colors.cream }]}>
              A classic{'\n'}card-table favorite.
            </Text>
            <Text style={[styles.heroBody, { color: colors.mutedForeground }]}>
              Free to explore. Virtual points only.
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                feedback();
                router.push('/teen-patti');
              }}
              style={({ pressed }) => [
                styles.heroButton,
                { backgroundColor: colors.primary, opacity: pressed ? 0.84 : 1 },
              ]}
              testID="teen-patti-open-button"
            >
              <Text style={[styles.heroButtonText, { color: colors.primaryForeground }]}>
                Play Teen Patti
              </Text>
              <Feather name="arrow-up-right" size={16} color={colors.primaryForeground} />
            </Pressable>
          </View>
          <View pointerEvents="none" style={styles.heroArt}>
            <View style={[styles.playingCard, styles.cardBack, { backgroundColor: colors.secondary, borderColor: colors.goldSoft }]}>
              <Feather name="star" size={20} color={colors.primary} />
            </View>
            <View style={[styles.playingCard, styles.cardFront, { backgroundColor: colors.cream, borderColor: colors.cream }]}>
              <Feather name="heart" size={20} color={colors.destructive} />
              <View style={styles.cardLine} />
              <Feather name="layers" size={21} color={colors.heroStart} />
            </View>
            <View style={[styles.sparkleOne, { backgroundColor: colors.goldSoft }]} />
            <View style={[styles.sparkleTwo, { borderColor: colors.goldSoft }]} />
          </View>
        </LinearGradient>

        <Pressable
          accessibilityRole="button"
          onPress={() => {
            feedback();
            router.push('/points');
          }}
          style={({ pressed }) => [
            styles.balanceCard,
            { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.85 : 1 },
          ]}
          testID="virtual-points-card"
        >
          <View style={[styles.balanceIcon, { backgroundColor: colors.accent }]}>
            <Feather name="circle" size={18} color={colors.primary} />
          </View>
          <View style={styles.balanceCopy}>
            <Text style={[styles.balanceLabel, { color: colors.mutedForeground }]}>
              YOUR VIRTUAL POINTS
            </Text>
            <Text style={[styles.balanceValue, { color: colors.foreground }]}>
              {isLoaded ? balance.toLocaleString('en-IN') : '···'} <Text style={[styles.balanceUnit, { color: colors.mutedForeground }]}>practice points</Text>
            </Text>
          </View>
          <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
        </Pressable>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Find your game
            </Text>
            <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
              A little something for every table
            </Text>
          </View>
          <Text style={[styles.gameCount, { color: colors.mutedForeground }]}>06 GAMES</Text>
        </View>

        <View style={styles.gameGrid}>
          {games.map((game) => {
            const content = (
              <>
                <View style={[styles.gameIcon, { backgroundColor: colors.secondary }]}>
                  <Feather name={game.icon} size={20} color={colors.goldSoft} />
                </View>
                <Text style={[styles.gameName, { color: colors.foreground }]}>{game.name}</Text>
                <Text
                  style={[
                    styles.comingSoon,
                    { color: game.available ? colors.success : colors.mutedForeground },
                  ]}
                >
                  {game.available ? 'PLAY NOW' : 'COMING SOON'}
                </Text>
              </>
            );

            if (game.available) {
              return (
                <Pressable
                  key={game.name}
                  accessibilityRole="button"
                  accessibilityLabel={`Play ${game.name}`}
                  onPress={() => {
                    feedback();
                    router.push('/rummy');
                  }}
                  style={({ pressed }) => [
                    styles.gameCard,
                    {
                      backgroundColor: colors.card,
                      borderColor: colors.primary,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                  testID="home-rummy-button"
                >
                  {content}
                </Pressable>
              );
            }

            return (
              <View
                key={game.name}
                accessibilityLabel={`${game.name}, coming soon`}
                style={[
                  styles.gameCard,
                  { backgroundColor: colors.card, borderColor: colors.border },
                ]}
              >
                {content}
              </View>
            );
          })}
        </View>

        <View style={styles.footerLinks}>
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              feedback();
              router.push('/rules');
            }}
            style={({ pressed }) => [
              styles.footerLink,
              { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.8 : 1 },
            ]}
            testID="rules-link"
          >
            <View style={[styles.footerIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="book-open" size={17} color={colors.primary} />
            </View>
            <View style={styles.footerLinkCopy}>
              <Text style={[styles.footerLinkTitle, { color: colors.foreground }]}>Rules</Text>
              <Text style={[styles.footerLinkBody, { color: colors.mutedForeground }]}>Play fair, play for fun</Text>
            </View>
            <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
          </Pressable>
          <View style={[styles.footerNote, { borderColor: colors.border }]}>
            <Feather name="shield" size={14} color={colors.success} />
            <Text style={[styles.footerNoteText, { color: colors.mutedForeground }]}>
              Free to play · Virtual points only · No cash value
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 12, gap: 18 },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandMark: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  brandTitle: { fontSize: 15, fontFamily: 'Inter_700Bold', letterSpacing: 1.25 },
  brandCaption: { fontSize: 9, fontFamily: 'Inter_600SemiBold', letterSpacing: 1.15, marginTop: 3 },
  pointsPill: { minHeight: 38, paddingHorizontal: 12, borderRadius: 20, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 7 },
  pointsPillText: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  hero: { minHeight: 226, borderRadius: 24, padding: 20, justifyContent: 'center', overflow: 'hidden' },
  heroCopy: { width: '72%', zIndex: 1 },
  availableTag: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 7, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 6, marginBottom: 13 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  availableText: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.65 },
  heroTitle: { fontSize: 25, lineHeight: 31, fontFamily: 'Inter_700Bold', letterSpacing: -0.6 },
  heroBody: { fontSize: 11, fontFamily: 'Inter_500Medium', marginTop: 7, marginBottom: 14 },
  heroButton: { alignSelf: 'flex-start', minHeight: 39, paddingHorizontal: 13, borderRadius: 13, flexDirection: 'row', alignItems: 'center', gap: 9 },
  heroButtonText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  heroArt: { position: 'absolute', right: 2, top: 24, bottom: 10, width: '36%', alignItems: 'center', justifyContent: 'center' },
  playingCard: { width: 69, height: 101, borderRadius: 12, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', gap: 9 },
  cardBack: { position: 'absolute', transform: [{ rotate: '14deg' }, { translateX: 17 }, { translateY: 1 }] },
  cardFront: { transform: [{ rotate: '-10deg' }, { translateX: -10 }, { translateY: 7 }] },
  cardLine: { width: 22, height: 1, backgroundColor: '#8B9C82', opacity: 0.8 },
  sparkleOne: { position: 'absolute', width: 5, height: 5, borderRadius: 3, top: 25, right: 21 },
  sparkleTwo: { position: 'absolute', width: 10, height: 10, borderRadius: 3, borderWidth: 1.3, bottom: 22, left: 0, transform: [{ rotate: '45deg' }] },
  balanceCard: { minHeight: 69, paddingHorizontal: 13, paddingVertical: 11, borderWidth: 1, borderRadius: 17, flexDirection: 'row', alignItems: 'center', gap: 11 },
  balanceIcon: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  balanceCopy: { flex: 1, gap: 4 },
  balanceLabel: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.7 },
  balanceValue: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  balanceUnit: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  sectionHeading: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 1 },
  sectionTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', letterSpacing: -0.4 },
  sectionSubtitle: { fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 4 },
  gameCount: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.8, paddingBottom: 3 },
  gameGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 10 },
  gameCard: { width: '48.3%', minHeight: 110, borderRadius: 17, borderWidth: 1, paddingHorizontal: 13, paddingVertical: 12, justifyContent: 'space-between' },
  gameIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  gameName: { fontSize: 12, fontFamily: 'Inter_600SemiBold', marginTop: 9 },
  comingSoon: { fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 0.8, marginTop: 4 },
  footerLinks: { gap: 11 },
  footerLink: { minHeight: 66, borderRadius: 16, borderWidth: 1, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, gap: 11 },
  footerIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  footerLinkCopy: { flex: 1, gap: 3 },
  footerLinkTitle: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  footerLinkBody: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  footerNote: { borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7 },
  footerNoteText: { fontSize: 9, fontFamily: 'Inter_500Medium' },
});
