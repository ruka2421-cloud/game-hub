import { Feather } from '@expo/vector-icons';
import React from 'react';
import { Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useVirtualPoints } from '@/context/VirtualPointsContext';

export default function PointsScreen() {
  const colors = useColors();
  const { balance, isLoaded, storageWarning } = useVirtualPoints();

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.safeArea,
        { backgroundColor: colors.background, paddingTop: Platform.OS === 'web' ? 67 : 0 },
      ]}
    >
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>JUST FOR PLAY</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Virtual points</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          A simple score for friendly practice.
        </Text>

        <View style={[styles.balanceCard, { backgroundColor: colors.heroStart }]}>
          <View style={[styles.coin, { backgroundColor: colors.primary }]}>
            <Feather name="circle" size={23} color={colors.primaryForeground} />
          </View>
          <Text style={[styles.balanceLabel, { color: colors.goldSoft }]}>STARTING BALANCE</Text>
          <Text style={[styles.balance, { color: colors.cream }]}>
            {isLoaded ? balance.toLocaleString('en-IN') : '···'}
          </Text>
          <Text style={[styles.balanceUnit, { color: colors.mutedForeground }]}>practice points</Text>
        </View>

        {storageWarning ? (
          <View style={[styles.warning, { backgroundColor: colors.secondary }]}>
            <Feather name="alert-circle" size={16} color={colors.goldSoft} />
            <Text style={[styles.warningText, { color: colors.secondaryForeground }]}>
              {storageWarning}
            </Text>
          </View>
        ) : null}

        <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.infoIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="shield" size={18} color={colors.success} />
          </View>
          <View style={styles.infoCopy}>
            <Text style={[styles.infoTitle, { color: colors.foreground }]}>Points stay virtual</Text>
            <Text style={[styles.infoBody, { color: colors.mutedForeground }]}>
              They have no cash value and cannot be exchanged or redeemed.
            </Text>
          </View>
        </View>
        <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.infoIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="heart" size={18} color={colors.primary} />
          </View>
          <View style={styles.infoCopy}>
            <Text style={[styles.infoTitle, { color: colors.foreground }]}>Free to play</Text>
            <Text style={[styles.infoBody, { color: colors.mutedForeground }]}>
              Game Hub is for casual play and friendly competition.
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 22, paddingTop: 23, paddingBottom: Platform.OS === 'web' ? 34 : 28, gap: 14 },
  eyebrow: { fontSize: 10, letterSpacing: 1.2, fontFamily: 'Inter_700Bold', marginBottom: -8 },
  title: { fontSize: 28, fontFamily: 'Inter_700Bold', letterSpacing: -0.8 },
  subtitle: { fontSize: 13, fontFamily: 'Inter_400Regular', lineHeight: 19, marginTop: -7 },
  balanceCard: { marginTop: 11, borderRadius: 23, alignItems: 'center', paddingVertical: 27, paddingHorizontal: 20 },
  coin: { width: 50, height: 50, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginBottom: 17 },
  balanceLabel: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 1 },
  balance: { fontSize: 43, lineHeight: 51, fontFamily: 'Inter_700Bold', letterSpacing: -1.7, marginTop: 4 },
  balanceUnit: { fontSize: 12, fontFamily: 'Inter_500Medium', marginTop: 1 },
  infoCard: { borderWidth: 1, borderRadius: 17, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
  infoIcon: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  infoCopy: { flex: 1, gap: 4 },
  infoTitle: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  infoBody: { fontSize: 10, fontFamily: 'Inter_400Regular', lineHeight: 15 },
  warning: { borderRadius: 14, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 9 },
  warningText: { flex: 1, fontSize: 10, fontFamily: 'Inter_500Medium', lineHeight: 15 },
});
