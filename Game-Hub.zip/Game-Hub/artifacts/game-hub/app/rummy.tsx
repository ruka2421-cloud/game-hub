import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import {
  createNextRummyRound,
  createRummyGame,
  discardForHuman,
  drawForHuman,
  isWildCard,
  playComputerTurn,
  rankName,
  RummyCard,
  RummyGameState,
  RummyMeld,
  RummyPlayer,
  scoreRummyHand,
  selectRummyDiscard,
  suitSymbol,
  validateRummyHand,
} from '@/utils/rummy';

function GameCard({
  card,
  hidden = false,
  small = false,
  selected = false,
  highlighted = false,
  disabled = false,
  onPress,
  accessibilityLabel,
}: {
  card?: RummyCard;
  hidden?: boolean;
  small?: boolean;
  selected?: boolean;
  highlighted?: boolean;
  disabled?: boolean;
  onPress?: () => void;
  accessibilityLabel?: string;
}) {
  const colors = useColors();
  const isRed = card?.suit === 'Hearts' || card?.suit === 'Diamonds';
  const cardColor = isRed ? colors.destructive : colors.heroStart;
  const rank = card ? rankName(card.rank) : '';
  const symbol = card ? suitSymbol(card.suit) : '';
  const joker = card?.printedJoker;

  const cardStyle = [
    small ? styles.smallFaceCard : styles.faceCard,
    {
      backgroundColor: colors.cream,
      borderColor: highlighted ? colors.primary : selected ? colors.success : colors.goldSoft,
      opacity: disabled ? 0.45 : 1,
    },
    selected && styles.selectedCard,
  ];

  if (hidden) {
    return (
      <View
        style={[
          small ? styles.smallCardBack : styles.cardBack,
          { backgroundColor: colors.secondary, borderColor: colors.border },
        ]}
      >
        <Feather name="layers" size={small ? 10 : 15} color={colors.primary} />
      </View>
    );
  }

  const content = (
    <View style={cardStyle}>
      <Text style={[small ? styles.smallRank : styles.cardRank, { color: cardColor }]}>
        {joker ? 'JOKER' : rank}
      </Text>
      <Text style={[small ? styles.smallSuit : styles.cardSuit, { color: cardColor }]}>
        {symbol}
      </Text>
      {!small && highlighted ? (
        <Text style={[styles.wildCaption, { color: cardColor }]}>WILD</Text>
      ) : null}
    </View>
  );

  if (!onPress) return content;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? `${rank} ${card?.suit ?? 'joker'}`}
      accessibilityState={{ selected, disabled }}
      disabled={disabled}
      onPress={onPress}
      testID={card ? `rummy-card-${card.id}` : undefined}
    >
      {content}
    </Pressable>
  );
}

function TableButton({
  label,
  icon,
  onPress,
  disabled,
  primary = false,
  testID,
  detail,
}: {
  label: string;
  icon: React.ComponentProps<typeof Feather>['name'];
  onPress: () => void;
  disabled: boolean;
  primary?: boolean;
  testID: string;
  detail?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.actionButton,
        {
          backgroundColor: primary ? colors.primary : colors.card,
          borderColor: primary ? colors.primary : colors.border,
          opacity: disabled ? 0.42 : pressed ? 0.8 : 1,
        },
      ]}
      testID={testID}
    >
      <Feather
        name={icon}
        size={16}
        color={primary ? colors.primaryForeground : colors.foreground}
      />
      <View style={styles.actionCopy}>
        <Text style={[styles.actionLabel, { color: primary ? colors.primaryForeground : colors.foreground }]}>
          {label}
        </Text>
        {detail ? (
          <Text style={[styles.actionDetail, { color: primary ? colors.primaryForeground : colors.mutedForeground }]}>
            {detail}
          </Text>
        ) : null}
      </View>
    </Pressable>
  );
}

function OpponentSeat({
  player,
  isCurrent,
  reveal,
  wildRank,
}: {
  player: RummyPlayer;
  isCurrent: boolean;
  reveal: boolean;
  wildRank: number | null;
}) {
  const colors = useColors();
  const score = reveal ? scoreRummyHand(player.hand, wildRank) : null;

  return (
    <View
      style={[
        styles.opponentSeat,
        {
          backgroundColor: isCurrent ? colors.accent : colors.card,
          borderColor: isCurrent ? colors.primary : colors.border,
        },
      ]}
      testID={`rummy-seat-${player.id}`}
    >
      <View style={styles.opponentHead}>
        <View style={[styles.opponentAvatar, { backgroundColor: colors.secondary }]}>
          <Feather name="user" size={12} color={colors.goldSoft} />
        </View>
        <View style={styles.opponentInfo}>
          <Text numberOfLines={1} style={[styles.opponentName, { color: colors.foreground }]}>
            {player.name}
          </Text>
          <Text style={[styles.opponentStatus, { color: isCurrent ? colors.goldSoft : colors.mutedForeground }]}>
            {reveal ? `${score?.penalty ?? 0} THIS ROUND` : isCurrent ? 'THINKING' : 'COMPUTER'}
          </Text>
        </View>
      </View>
      <View style={styles.opponentCards}>
        {player.hand.slice(0, reveal ? 13 : 3).map((card, index) => (
          <GameCard
            key={card.id}
            card={reveal ? card : undefined}
            hidden={!reveal}
            small
          />
        ))}
        {!reveal && player.hand.length > 3 ? (
          <Text style={[styles.hiddenCount, { color: colors.mutedForeground }]}>
            +{player.hand.length - 3}
          </Text>
        ) : null}
      </View>
      <Text style={[styles.opponentTotal, { color: colors.mutedForeground }]}>
        Match penalty {player.totalPenalty}
      </Text>
    </View>
  );
}

function MeldSummary({ groups }: { groups: RummyMeld[] }) {
  const colors = useColors();
  return (
    <View style={styles.meldList}>
      {groups.map((group, index) => (
        <View
          key={`${group.kind}-${index}`}
          style={[styles.meldRow, { backgroundColor: colors.secondary }]}
        >
          <Text style={[styles.meldType, { color: group.pure ? colors.success : colors.goldSoft }]}>
            {group.kind === 'sequence' ? (group.pure ? 'PURE SEQUENCE' : 'SEQUENCE') : 'SET'}
          </Text>
          <Text style={[styles.meldCards, { color: colors.foreground }]}>
            {group.cards.map((card) => `${rankName(card.rank)}${suitSymbol(card.suit)}`).join('  ')}
          </Text>
        </View>
      ))}
    </View>
  );
}

export default function RummyScreen() {
  const colors = useColors();
  const [game, setGame] = useState<RummyGameState>(() => createRummyGame(4));

  useEffect(() => {
    if (game.phase !== 'draw' || game.result) return;
    const currentPlayer = game.players[game.currentPlayerIndex];
    if (!currentPlayer || currentPlayer.isHuman) return;
    const timer = setTimeout(() => {
      setGame((current) => playComputerTurn(current));
    }, 650);
    return () => clearTimeout(timer);
  }, [game.currentPlayerIndex, game.phase, game.result, game.roundNumber]);

  const human = game.players.find((player) => player.isHuman);
  const selectedCard = human?.hand.find((card) => card.id === game.selectedDiscardId);
  const selectedHand = useMemo(
    () => (human && selectedCard ? human.hand.filter((card) => card.id !== selectedCard.id) : []),
    [human, selectedCard],
  );
  const selectedValidation = useMemo(
    () => (selectedHand.length === 13 ? validateRummyHand(selectedHand, game.wildRank) : null),
    [game.wildRank, selectedHand],
  );
  const selectedIsForbidden =
    game.drawnFrom === 'discard' && selectedCard?.id === game.drawnCardId;
  const canDeclare = Boolean(selectedValidation?.valid && !selectedIsForbidden);
  const currentPlayer = game.players[game.currentPlayerIndex];
  const isHumanTurn = Boolean(currentPlayer?.isHuman && game.phase !== 'round-over');
  const opponentPlayers = game.players.filter((player) => !player.isHuman);
  const winner = game.result?.winnerId
    ? game.players.find((player) => player.id === game.result?.winnerId)
    : undefined;

  const startNewGame = (playerCount = game.players.length) => {
    setGame(createRummyGame(playerCount));
  };

  const requestNewGame = () => {
    if (game.phase === 'round-over') {
      startNewGame();
      return;
    }
    Alert.alert('Start a new game?', 'This will reset the current match score and deal a new hand.', [
      { text: 'Keep playing', style: 'cancel' },
      { text: 'New Game', style: 'destructive', onPress: () => startNewGame() },
    ]);
  };

  const choosePlayerCount = (playerCount: number) => {
    if (playerCount === game.players.length) return;
    const start = () => startNewGame(playerCount);
    if (game.phase === 'round-over') {
      start();
      return;
    }
    Alert.alert(
      'Change player count?',
      'Starting with a different number of players resets the current match.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Start new match', style: 'destructive', onPress: start },
      ],
    );
  };

  const handleDraw = (source: 'stock' | 'discard') => {
    void Haptics.selectionAsync();
    setGame((current) => drawForHuman(current, source));
  };

  const handleDiscard = (declare: boolean) => {
    void Haptics.selectionAsync();
    setGame((current) => discardForHuman(current, declare));
  };

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.safeArea,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === 'web' ? 67 : 0,
        },
      ]}
    >
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === 'web' ? 34 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topBar}>
          <View style={styles.titleWrap}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>GAME HUB · FREE PLAY</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Indian Rummy</Text>
          </View>
          <View style={styles.topActions}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Open Rummy rules"
              onPress={() => router.push('/rummy-rules')}
              style={({ pressed }) => [
                styles.iconButton,
                { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
              ]}
              testID="rummy-rules-button"
            >
              <Feather name="book-open" size={17} color={colors.primary} />
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Exit to home"
              onPress={() => router.replace('/')}
              style={({ pressed }) => [
                styles.iconButton,
                { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
              ]}
              testID="rummy-exit-home"
            >
              <Feather name="home" size={18} color={colors.foreground} />
            </Pressable>
          </View>
        </View>

        <View style={[styles.freePlayBanner, { backgroundColor: colors.accent, borderColor: colors.border }]}>
          <Feather name="shield" size={14} color={colors.success} />
          <Text style={[styles.freePlayText, { color: colors.foreground }]}>
            No stakes · Rummy match scores only · no cash value
          </Text>
        </View>

        <View style={styles.settingsRow}>
          <View>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>Players</Text>
            <Text style={[styles.settingSub, { color: colors.mutedForeground }]}>
              You + computer opponents
            </Text>
          </View>
          <View style={[styles.segment, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {[2, 3, 4].map((count) => (
              <Pressable
                key={count}
                accessibilityRole="button"
                accessibilityLabel={`${count} players`}
                accessibilityState={{ selected: count === game.players.length }}
                onPress={() => choosePlayerCount(count)}
                style={[
                  styles.segmentButton,
                  count === game.players.length && { backgroundColor: colors.primary },
                ]}
                testID={`rummy-player-count-${count}`}
              >
                <Text
                  style={[
                    styles.segmentText,
                    { color: count === game.players.length ? colors.primaryForeground : colors.mutedForeground },
                  ]}
                >
                  {count}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={[styles.wildPanel, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.wildIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="star" size={16} color={colors.goldSoft} />
          </View>
          <View style={styles.wildCopy}>
            <Text style={[styles.wildTitle, { color: colors.foreground }]}>Wild joker</Text>
            <Text style={[styles.wildSubtitle, { color: colors.mutedForeground }]}>
              {game.wildRank === null
                ? 'Printed jokers · no wild rank this round'
                : `${rankName(game.wildRank)}s and printed jokers · natural use can be pure`}
            </Text>
          </View>
          <GameCard card={game.wildMarker} small />
        </View>

        {opponentPlayers.length > 0 ? (
          <View style={styles.opponentGrid}>
            {opponentPlayers.map((player) => (
              <OpponentSeat
                key={player.id}
                player={player}
                isCurrent={game.phase !== 'round-over' && game.currentPlayerIndex === game.players.findIndex((entry) => entry.id === player.id)}
                reveal={game.phase === 'round-over'}
                wildRank={game.wildRank}
              />
            ))}
          </View>
        ) : null}

        <View style={[styles.tablePanel, { backgroundColor: colors.heroStart, borderColor: colors.border }]}>
          <View style={styles.tableHeading}>
            <View>
              <Text style={[styles.tableEyebrow, { color: colors.goldSoft }]}>
                ROUND {game.roundNumber}
              </Text>
              <Text style={[styles.tableStatus, { color: colors.cream }]}>
                {game.phase === 'round-over'
                  ? 'Round complete'
                  : isHumanTurn
                    ? game.phase === 'draw' ? 'Your turn · draw a card' : 'Your turn · discard a card'
                    : `${currentPlayer?.name ?? 'Computer'} is playing`}
              </Text>
            </View>
            <Text style={[styles.stockCount, { color: colors.mutedForeground }]}>
              {game.drawPile.length} in stock
            </Text>
          </View>

          <View style={styles.pilesRow}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Draw from stock, ${game.drawPile.length} cards`}
              disabled={!isHumanTurn || game.phase !== 'draw'}
              onPress={() => handleDraw('stock')}
              style={({ pressed }) => [
                styles.pileAction,
                { opacity: !isHumanTurn || game.phase !== 'draw' ? 0.48 : pressed ? 0.75 : 1 },
              ]}
              testID="rummy-draw-stock"
            >
              <GameCard hidden />
              <Text style={[styles.pileTitle, { color: colors.cream }]}>Draw stock</Text>
              <Text style={[styles.pileDetail, { color: colors.mutedForeground }]}>face down</Text>
            </Pressable>
            <View style={styles.discardPile}>
              <Text style={[styles.pileTitle, { color: colors.cream }]}>Discard pile</Text>
              {game.discardPile.length > 0 ? (
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Take top discard"
                  disabled={!isHumanTurn || game.phase !== 'draw'}
                  onPress={() => handleDraw('discard')}
                  style={({ pressed }) => ({ opacity: !isHumanTurn || game.phase !== 'draw' ? 0.48 : pressed ? 0.75 : 1 })}
                  testID="rummy-draw-discard"
                >
                  <GameCard card={game.discardPile[game.discardPile.length - 1]} />
                </Pressable>
              ) : (
                <View style={[styles.emptyPile, { borderColor: colors.border }]}>
                  <Feather name="minus" size={16} color={colors.mutedForeground} />
                </View>
              )}
              <Text style={[styles.pileDetail, { color: colors.mutedForeground }]}>top card</Text>
            </View>
          </View>
        </View>

        <View style={styles.messageRow}>
          <Feather
            name={game.phase === 'round-over' ? 'award' : 'info'}
            size={15}
            color={game.phase === 'round-over' ? colors.primary : colors.mutedForeground}
          />
          <Text style={[styles.messageText, { color: colors.mutedForeground }]} testID="rummy-game-message">
            {game.message}
          </Text>
        </View>

        <View style={styles.handHeading}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Your hand</Text>
            <Text style={[styles.sectionCaption, { color: colors.mutedForeground }]}>
              {human?.hand.length ?? 0} cards · {
                game.phase === 'draw'
                  ? 'draw before choosing a discard'
                  : game.phase === 'discard'
                    ? 'tap a card to select your discard'
                    : 'round complete'
              }
            </Text>
          </View>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.handRow}
          testID="rummy-player-hand"
        >
          {human?.hand.map((card) => {
            const forbidden = game.drawnFrom === 'discard' && game.drawnCardId === card.id;
            return (
              <GameCard
                key={card.id}
                card={card}
                selected={game.selectedDiscardId === card.id}
                highlighted={isWildCard(card, game.wildRank)}
                disabled={!isHumanTurn || game.phase !== 'discard' || forbidden}
                accessibilityLabel={`${rankName(card.rank)} ${card.suit ?? 'joker'}${forbidden ? ', just drawn and cannot be discarded yet' : ''}`}
                onPress={() => setGame((current) => selectRummyDiscard(current, card.id))}
              />
            );
          })}
        </ScrollView>

        {isHumanTurn && game.phase === 'discard' ? (
          <View style={styles.actionGrid}>
            <TableButton
              label="Discard"
              detail="End your turn"
              icon="corner-up-right"
              disabled={!selectedCard || Boolean(selectedIsForbidden)}
              onPress={() => handleDiscard(false)}
              testID="rummy-discard-button"
            />
            <TableButton
              label="Show / Declare"
              detail={selectedIsForbidden ? 'Choose another card' : canDeclare ? 'Valid 13-card hand' : 'Requires 2 sequences + pure'}
              icon="check-circle"
              disabled={!canDeclare}
              primary={canDeclare}
              onPress={() => handleDiscard(true)}
              testID="rummy-declare-button"
            />
          </View>
        ) : null}

        {game.phase === 'round-over' && game.result ? (
          <View style={[styles.resultPanel, { backgroundColor: colors.card, borderColor: colors.primary }]}>
            <View style={styles.resultHeading}>
              <View style={[styles.resultIcon, { backgroundColor: colors.accent }]}>
                <Feather name="award" size={19} color={colors.primary} />
              </View>
              <View style={styles.resultHeadingCopy}>
                <Text style={[styles.resultTitle, { color: colors.foreground }]}>
                  {winner?.name ?? 'Player'} wins the round
                </Text>
                <Text style={[styles.resultSubtitle, { color: colors.mutedForeground }]}>
                  Valid 13-card declaration · winner scores 0
                </Text>
              </View>
            </View>

            <Text style={[styles.scoreHeader, { color: colors.mutedForeground }]}>
              ROUND PENALTY · MATCH TOTAL
            </Text>
            {game.result.scores.map((score) => {
              const player = game.players.find((entry) => entry.id === score.playerId);
              return (
                <View key={score.playerId} style={[styles.scoreRow, { borderTopColor: colors.border }]}>
                  <Text style={[styles.scoreName, { color: colors.foreground }]}>
                    {player?.name ?? 'Player'}
                  </Text>
                  <Text style={[styles.scoreValue, { color: colors.foreground }]}>
                    {score.roundPenalty} · {score.totalPenalty}
                  </Text>
                </View>
              );
            })}

            <Text style={[styles.meldHeading, { color: colors.foreground }]}>Winning show</Text>
            <MeldSummary groups={game.result.winningGroups} />

            <View style={styles.resultActions}>
              <TableButton
                label="New Round"
                detail="Keep match totals"
                icon="repeat"
                disabled={false}
                primary
                onPress={() => setGame((current) => createNextRummyRound(current))}
                testID="rummy-new-round"
              />
              <TableButton
                label="New Game"
                detail="Reset match scores"
                icon="refresh-cw"
                disabled={false}
                onPress={() => startNewGame()}
                testID="rummy-new-game-result"
              />
            </View>
          </View>
        ) : null}

        <View style={[styles.matchPanel, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.matchHeading}>
            <View>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Match scores</Text>
              <Text style={[styles.sectionCaption, { color: colors.mutedForeground }]}>Lower penalty is better</Text>
            </View>
            <Pressable
              accessibilityRole="button"
              onPress={requestNewGame}
              style={({ pressed }) => [
                styles.newGameButton,
                { backgroundColor: colors.secondary, opacity: pressed ? 0.75 : 1 },
              ]}
              testID="rummy-new-game"
            >
              <Feather name="refresh-cw" size={13} color={colors.goldSoft} />
              <Text style={[styles.newGameText, { color: colors.foreground }]}>New Game</Text>
            </Pressable>
          </View>
          {game.players.map((player) => (
            <View key={player.id} style={[styles.matchRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.matchName, { color: colors.foreground }]}>
                {player.name}{player.isHuman ? ' (you)' : ''}
              </Text>
              <Text style={[styles.matchScore, { color: colors.goldSoft }]}>
                {player.totalPenalty} pts
              </Text>
            </View>
          ))}
          <Text style={[styles.walletNote, { color: colors.mutedForeground }]}>
            These are non-transferable match penalty scores. Your shared Game Hub virtual balance is unchanged.
          </Text>
        </View>

        <View style={styles.footerRow}>
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/rummy-rules')}
            style={({ pressed }) => [styles.footerButton, { opacity: pressed ? 0.72 : 1 }]}
            testID="rummy-footer-rules"
          >
            <Feather name="book-open" size={14} color={colors.primary} />
            <Text style={[styles.footerButtonText, { color: colors.foreground }]}>Rules / How to Play</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            onPress={() => router.replace('/')}
            style={({ pressed }) => [styles.footerButton, { opacity: pressed ? 0.72 : 1 }]}
            testID="rummy-footer-home"
          >
            <Feather name="home" size={14} color={colors.primary} />
            <Text style={[styles.footerButtonText, { color: colors.foreground }]}>Exit Home</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 16, paddingTop: 10, gap: 14 },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  titleWrap: { gap: 3 },
  eyebrow: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 1.05 },
  title: { fontSize: 23, fontFamily: 'Inter_700Bold', letterSpacing: -0.55 },
  topActions: { flexDirection: 'row', gap: 8 },
  iconButton: { width: 40, height: 40, borderRadius: 13, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  freePlayBanner: { minHeight: 36, borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  freePlayText: { fontSize: 9, fontFamily: 'Inter_600SemiBold', flex: 1 },
  settingsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  settingTitle: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  settingSub: { fontSize: 9, fontFamily: 'Inter_400Regular', marginTop: 2 },
  segment: { flexDirection: 'row', borderRadius: 12, borderWidth: 1, padding: 3, gap: 3 },
  segmentButton: { minWidth: 31, height: 28, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  segmentText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  wildPanel: { minHeight: 61, borderRadius: 16, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 7, flexDirection: 'row', alignItems: 'center', gap: 10 },
  wildIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  wildCopy: { flex: 1, gap: 3 },
  wildTitle: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  wildSubtitle: { fontSize: 9, lineHeight: 13, fontFamily: 'Inter_400Regular' },
  opponentGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  opponentSeat: { minHeight: 105, flexGrow: 1, flexBasis: '30%', borderRadius: 14, borderWidth: 1, padding: 8, justifyContent: 'space-between' },
  opponentHead: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  opponentAvatar: { width: 24, height: 24, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  opponentInfo: { flex: 1, minWidth: 0 },
  opponentName: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  opponentStatus: { fontSize: 7, fontFamily: 'Inter_700Bold', marginTop: 2, letterSpacing: 0.2 },
  opponentCards: { flexDirection: 'row', alignItems: 'center', paddingLeft: 1, minHeight: 34, marginTop: 6 },
  hiddenCount: { fontSize: 8, fontFamily: 'Inter_600SemiBold', marginLeft: 4 },
  opponentTotal: { fontSize: 8, fontFamily: 'Inter_500Medium', marginTop: 5 },
  tablePanel: { borderRadius: 20, borderWidth: 1, padding: 14, gap: 12 },
  tableHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  tableEyebrow: { fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 0.9 },
  tableStatus: { fontSize: 12, fontFamily: 'Inter_700Bold', marginTop: 3 },
  stockCount: { fontSize: 9, fontFamily: 'Inter_500Medium' },
  pilesRow: { minHeight: 130, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 26 },
  pileAction: { minWidth: 88, alignItems: 'center', justifyContent: 'center', gap: 6 },
  discardPile: { minWidth: 96, alignItems: 'center', justifyContent: 'center', gap: 6 },
  pileTitle: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  pileDetail: { fontSize: 8, fontFamily: 'Inter_400Regular' },
  emptyPile: { width: 54, height: 77, borderWidth: 1, borderRadius: 9, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center' },
  cardBack: { width: 54, height: 77, borderRadius: 9, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  smallCardBack: { width: 22, height: 31, borderRadius: 5, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  faceCard: { width: 54, height: 77, borderWidth: 1.5, borderRadius: 9, paddingHorizontal: 5, paddingTop: 4, alignItems: 'flex-start', justifyContent: 'flex-start' },
  smallFaceCard: { width: 22, height: 31, borderWidth: 1, borderRadius: 5, paddingHorizontal: 2, paddingTop: 2, alignItems: 'flex-start', justifyContent: 'flex-start' },
  selectedCard: { transform: [{ translateY: -8 }] },
  cardRank: { fontSize: 13, lineHeight: 16, fontFamily: 'Inter_700Bold' },
  cardSuit: { fontSize: 20, lineHeight: 23, fontFamily: 'Inter_600SemiBold', alignSelf: 'center' },
  smallRank: { fontSize: 7, lineHeight: 8, fontFamily: 'Inter_700Bold' },
  smallSuit: { fontSize: 8, lineHeight: 10, fontFamily: 'Inter_600SemiBold', alignSelf: 'center' },
  wildCaption: { fontSize: 6, fontFamily: 'Inter_700Bold', alignSelf: 'center', marginTop: 1 },
  messageRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 2 },
  messageText: { flex: 1, fontSize: 10, lineHeight: 15, fontFamily: 'Inter_500Medium' },
  handHeading: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', gap: 8 },
  sectionTitle: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  sectionCaption: { fontSize: 9, fontFamily: 'Inter_400Regular', marginTop: 3 },
  handRow: { paddingTop: 9, paddingBottom: 3, paddingHorizontal: 3, gap: 6 },
  actionGrid: { flexDirection: 'row', gap: 8 },
  actionButton: { minHeight: 52, flex: 1, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  actionCopy: { flex: 1 },
  actionLabel: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  actionDetail: { fontSize: 8, fontFamily: 'Inter_400Regular', marginTop: 2 },
  resultPanel: { borderWidth: 1, borderRadius: 18, padding: 13, gap: 10 },
  resultHeading: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  resultIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  resultHeadingCopy: { flex: 1, gap: 3 },
  resultTitle: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  resultSubtitle: { fontSize: 9, fontFamily: 'Inter_400Regular' },
  scoreHeader: { fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 0.6, marginTop: 2 },
  scoreRow: { minHeight: 31, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  scoreName: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  scoreValue: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  meldHeading: { fontSize: 11, fontFamily: 'Inter_700Bold', marginTop: 4 },
  meldList: { gap: 6 },
  meldRow: { borderRadius: 10, padding: 8, gap: 4 },
  meldType: { fontSize: 7, fontFamily: 'Inter_700Bold', letterSpacing: 0.5 },
  meldCards: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  resultActions: { flexDirection: 'row', gap: 8, marginTop: 3 },
  matchPanel: { borderWidth: 1, borderRadius: 16, padding: 12, gap: 2 },
  matchHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 },
  newGameButton: { minHeight: 34, borderRadius: 11, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 6 },
  newGameText: { fontSize: 9, fontFamily: 'Inter_700Bold' },
  matchRow: { minHeight: 30, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  matchName: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  matchScore: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  walletNote: { fontSize: 8, lineHeight: 13, fontFamily: 'Inter_400Regular', marginTop: 6 },
  footerRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 8, paddingBottom: 4 },
  footerButton: { minHeight: 38, flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7 },
  footerButtonText: { fontSize: 9, fontFamily: 'Inter_600SemiBold' },
});

