import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

const ruleSections = [
  {
    title: 'The table and deal',
    body: 'This Game Hub version is for 2–4 players. It uses two standard 52-card decks, each with one printed joker (106 cards total). Each player is dealt 13 cards. A standard card is turned as the wild-rank marker and is not part of the playable stock; one face-up card starts the discard pile. Your turn is first, then computer players act clockwise.',
  },
  {
    title: 'Your turn: draw, then discard',
    body: 'Draw exactly one card from the face-down stock or take the top card of the face-up discard pile. Then discard one card from your 14-card hand, returning to 13 cards. A card taken from the discard pile cannot be discarded on that same turn. When the stock runs out, the discard pile is shuffled back into it except for its top card.',
  },
  {
    title: 'Sequences and sets',
    body: 'A sequence is at least three consecutive ranks of the same suit, such as 4♣–5♣–6♣. A set is three or four cards of the same rank in different suits. Duplicate copies of the same suit cannot fill two places in one set. Groups cannot overlap; every card in a declaration is used exactly once.',
  },
  {
    title: 'Jokers and the pure sequence',
    body: 'Both printed jokers and every card matching the wild-rank marker may substitute for a missing card in a sequence or set. The wild-rank card may also be used naturally as the rank and suit printed on it. At least one pure sequence is required: three or more consecutive cards of one suit with no joker used as a substitute. A wild-rank card used naturally can be part of a pure sequence.',
  },
  {
    title: 'Ace and declaration',
    body: 'Ace may be low (A–2–3, A–2–3–4, and so on) or high (Q–K–A), but runs never wrap: K–A–2 is invalid. To declare, discard one card and arrange the remaining 13 into non-overlapping sequences and sets. A valid declaration needs at least two sequences, including at least one pure sequence, and all 13 cards must belong to valid groups. An invalid declaration is rejected and does not end the round.',
  },
  {
    title: 'Round scoring',
    body: 'The first player to make a valid declaration wins the round and receives 0 penalty points. Each other player receives penalty points for cards that cannot be included in valid groups, provided their hand contains at least two sequences including a pure sequence. If either requirement is missing, their full hand is counted. Ace, King, Queen, Jack and 10 are worth 10; 2–9 are worth face value; jokers and wild-rank cards are worth 0. A hand is capped at 80 penalty points. Lower cumulative penalty totals are better.',
  },
  {
    title: 'Free-play points',
    body: 'Rummy points are match penalty scores only. No points are staked, transferred, or deducted from your Game Hub balance. Points have no cash value. There are no deposits, withdrawals, payments, prizes, or real-money wagering.',
  },
];

export default function RummyRulesScreen() {
  const colors = useColors();

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.safeArea,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === 'web' ? 67 : 0,
        },
      ]}
    >
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === 'web' ? 34 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Pressable
          accessibilityRole="button"
          onPress={() => router.back()}
          style={({ pressed }) => [
            styles.backButton,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              opacity: pressed ? 0.75 : 1,
            },
          ]}
          testID="rummy-rules-back"
        >
          <Feather name="arrow-left" size={18} color={colors.foreground} />
          <Text style={[styles.backText, { color: colors.foreground }]}>Back to Rummy</Text>
        </Pressable>

        <Text style={[styles.eyebrow, { color: colors.primary }]}>INDIAN RUMMY</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>How to play</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          One defined 13-card ruleset for this free, single-player game.
        </Text>

        <View style={styles.ruleList}>
          {ruleSections.map((rule, index) => (
            <View
              key={rule.title}
              style={[
                styles.ruleCard,
                { backgroundColor: colors.card, borderColor: colors.border },
              ]}
            >
              <View style={[styles.ruleNumber, { backgroundColor: colors.accent }]}>
                <Text style={[styles.ruleNumberText, { color: colors.goldSoft }]}>
                  {String(index + 1).padStart(2, '0')}
                </Text>
              </View>
              <View style={styles.ruleCopy}>
                <Text style={[styles.ruleTitle, { color: colors.foreground }]}>
                  {rule.title}
                </Text>
                <Text style={[styles.ruleBody, { color: colors.mutedForeground }]}>
                  {rule.body}
                </Text>
              </View>
            </View>
          ))}
        </View>

        <View style={[styles.freePlayNote, { backgroundColor: colors.accent, borderColor: colors.border }]}>
          <Feather name="shield" size={17} color={colors.success} />
          <Text style={[styles.freePlayText, { color: colors.foreground }]}>
            Free to play · virtual match scores only · no cash value
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 12, gap: 16 },
  backButton: {
    alignSelf: 'flex-start',
    minHeight: 42,
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingHorizontal: 12,
  },
  backText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  eyebrow: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.2, marginTop: 4 },
  title: { fontSize: 28, fontFamily: 'Inter_700Bold', letterSpacing: -0.7, marginTop: -12 },
  subtitle: { fontSize: 12, lineHeight: 19, fontFamily: 'Inter_400Regular', marginTop: -10 },
  ruleList: { gap: 10, marginTop: 3 },
  ruleCard: {
    borderWidth: 1,
    borderRadius: 17,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  ruleNumber: { width: 33, height: 33, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  ruleNumberText: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  ruleCopy: { flex: 1, gap: 6 },
  ruleTitle: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  ruleBody: { fontSize: 11, lineHeight: 18, fontFamily: 'Inter_400Regular' },
  freePlayNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 13,
    paddingVertical: 12,
    marginTop: 2,
  },
  freePlayText: { flex: 1, fontSize: 10, fontFamily: 'Inter_600SemiBold' },
});

