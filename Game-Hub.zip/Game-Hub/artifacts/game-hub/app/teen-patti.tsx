import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useVirtualPoints } from '@/context/VirtualPointsContext';
import { useColors } from '@/hooks/useColors';
import {
  ANTE_POINTS,
  GamePlayer,
  GameState,
  getActivePlayers,
  getChaalCost,
  getCurrentHuman,
  getNextStake,
  getRaiseCost,
  getShowCost,
  getWinners,
  PlayerAction,
  playComputerTurn,
  rankName,
  revealHumanCards,
  suitSymbol,
  createRound,
  applyHumanAction,
} from '@/utils/teenPatti';

function GameCard({
  rank,
  suit,
  hidden = false,
  small = false,
}: {
  rank?: number;
  suit?: GamePlayer['cards'][number]['suit'];
  hidden?: boolean;
  small?: boolean;
}) {
  const colors = useColors();
  const redSuit = suit === 'Hearts' || suit === 'Diamonds';

  if (hidden) {
    return (
      <View
        style={[
          small ? styles.smallCardBack : styles.cardBack,
          { backgroundColor: colors.secondary, borderColor: colors.border },
        ]}
      >
        <Feather name="layers" size={small ? 10 : 15} color={colors.primary} />
      </View>
    );
  }

  return (
    <View
      style={[
        small ? styles.smallFaceCard : styles.faceCard,
        { backgroundColor: colors.cream, borderColor: colors.goldSoft },
      ]}
    >
      <Text
        style={[
          small ? styles.smallRank : styles.cardRank,
          { color: redSuit ? colors.destructive : colors.heroStart },
        ]}
      >
        {rank === undefined ? '' : rankName(rank)}
      </Text>
      <Text
        style={[
          small ? styles.smallSuit : styles.cardSuit,
          { color: redSuit ? colors.destructive : colors.heroStart },
        ]}
      >
        {suit ? suitSymbol(suit) : ''}
      </Text>
    </View>
  );
}

function OpponentSeat({
  player,
  current,
  revealCards,
}: {
  player: GamePlayer;
  current: boolean;
  revealCards: boolean;
}) {
  const colors = useColors();
  const folded = player.folded;

  return (
    <View
      style={[
        styles.opponentSeat,
        {
          backgroundColor: current ? colors.accent : colors.card,
          borderColor: current ? colors.primary : colors.border,
          opacity: folded ? 0.5 : 1,
        },
      ]}
      testID={`seat-${player.id}`}
    >
      <View style={styles.opponentHeading}>
        <View style={[styles.opponentAvatar, { backgroundColor: colors.secondary }]}>
          <Feather name={folded ? 'minus' : 'user'} size={12} color={colors.goldSoft} />
        </View>
        <View style={styles.opponentNameWrap}>
          <Text numberOfLines={1} style={[styles.opponentName, { color: colors.foreground }]}>
            {player.name}
          </Text>
          <Text style={[styles.opponentStatus, { color: folded ? colors.mutedForeground : colors.goldSoft }]}>
            {folded ? 'PACKED' : current ? 'THINKING' : player.seen ? 'SEEN' : 'BLIND'}
          </Text>
        </View>
      </View>
      <View style={styles.opponentCards}>
        {player.cards.map((card, index) => (
          <GameCard
            key={`${player.id}-${index}`}
            rank={card.rank}
            suit={card.suit}
            hidden={!revealCards}
            small
          />
        ))}
      </View>
      <Text style={[styles.opponentBalance, { color: colors.mutedForeground }]}>
        {player.balance.toLocaleString('en-IN')} pts
      </Text>
    </View>
  );
}

function ActionButton({
  label,
  detail,
  icon,
  onPress,
  disabled,
  primary = false,
  testID,
}: {
  label: string;
  detail?: string;
  icon: React.ComponentProps<typeof Feather>['name'];
  onPress: () => void;
  disabled: boolean;
  primary?: boolean;
  testID: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.actionButton,
        {
          backgroundColor: primary ? colors.primary : colors.card,
          borderColor: primary ? colors.primary : colors.border,
          opacity: disabled ? 0.4 : pressed ? 0.78 : 1,
        },
      ]}
      testID={testID}
    >
      <Feather
        name={icon}
        size={15}
        color={primary ? colors.primaryForeground : colors.foreground}
      />
      <Text
        style={[
          styles.actionLabel,
          { color: primary ? colors.primaryForeground : colors.foreground },
        ]}
      >
        {label}
      </Text>
      {detail ? (
        <Text
          style={[
            styles.actionDetail,
            { color: primary ? colors.primaryForeground : colors.mutedForeground },
          ]}
        >
          {detail}
        </Text>
      ) : null}
    </Pressable>
  );
}

export default function TeenPattiScreen() {
  const colors = useColors();
  const { balance, isLoaded, saveBalance, storageWarning } = useVirtualPoints();
  const [game, setGame] = useState<GameState | null>(null);
  const roundCounter = useRef(0);

  useEffect(() => {
    if (!isLoaded || game) return;
    roundCounter.current = 1;
    setGame(createRound(balance, roundCounter.current));
  }, [balance, game, isLoaded]);

  useEffect(() => {
    if (!isLoaded || !game) return;
    const human = getCurrentHuman(game);
    if (human && human.balance !== balance) {
      void saveBalance(human.balance);
    }
  }, [balance, game, isLoaded, saveBalance]);

  useEffect(() => {
    if (!game || game.phase !== 'playing') return;
    const currentPlayer = game.players[game.currentTurnIndex];
    if (!currentPlayer || currentPlayer.isHuman) return;

    const timer = setTimeout(() => {
      setGame((current) => {
        if (!current || current.phase !== 'playing') return current;
        const activePlayer = current.players[current.currentTurnIndex];
        if (!activePlayer || activePlayer.isHuman) return current;
        return playComputerTurn(current);
      });
    }, 780);

    return () => clearTimeout(timer);
  }, [game]);

  const human = game ? getCurrentHuman(game) : undefined;
  const activePlayers = useMemo(
    () => (game ? getActivePlayers(game) : []),
    [game],
  );
  const currentPlayer = game?.players[game.currentTurnIndex];
  const humanTurn = !!currentPlayer?.isHuman && game?.phase === 'playing';
  const callCost = human && game ? getChaalCost(human, game.currentStake) : 0;
  const nextStake = game ? getNextStake(game.currentStake) : 0;
  const raiseCost =
    human && game
      ? (getRaiseCost(human, game.currentStake) ?? 0)
      : 0;
  const opponents = game?.players.filter((player) => !player.isHuman) ?? [];
  const showOpponent =
    activePlayers.length === 2
      ? activePlayers.find((player) => !player.isHuman)
      : undefined;
  const showCost =
    human && game && showOpponent
      ? getShowCost(human, showOpponent, game.currentStake)
      : null;
  const dealerName = game?.players.find((player) => player.dealer)?.name ?? '—';
  const winners = game ? getWinners(game) : [];
  const humanWon = winners.some((player) => player.isHuman);

  const handleAction = useCallback(
    (action: PlayerAction) => {
      if (!game || !humanTurn) return;
      void Haptics.selectionAsync();
      setGame((current) => (current ? applyHumanAction(current, action) : current));
    },
    [game, humanTurn],
  );

  const handleNewRound = useCallback(() => {
    const points = human?.balance ?? balance;
    roundCounter.current += 1;
    setGame(createRound(points, roundCounter.current));
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }, [balance, human]);

  const handleReveal = useCallback(() => {
    setGame((current) => (current ? revealHumanCards(current) : current));
    void Haptics.selectionAsync();
  }, []);

  const exitHome = useCallback(() => {
    router.replace('/');
  }, []);

  if (!isLoaded || !game || !human) {
    return (
      <SafeAreaView
        edges={['top', 'left', 'right']}
        style={[styles.safeArea, { backgroundColor: colors.background }]}
      >
        <View style={styles.loading}>
          <Feather name="layers" size={24} color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>
            Preparing the table…
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.safeArea,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === 'web' ? 67 : 0,
        },
      ]}
    >
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Platform.OS === 'web' ? 34 : 24 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Exit Teen Patti"
            onPress={exitHome}
            style={({ pressed }) => [
              styles.headerIconButton,
              { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
            ]}
            testID="exit-home"
          >
            <Feather name="arrow-left" size={18} color={colors.foreground} />
          </Pressable>
          <View style={styles.headerCopy}>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>Teen Patti</Text>
            <Text style={[styles.headerSub, { color: colors.mutedForeground }]}>
              ROUND {game.roundNumber} · VIRTUAL POINTS ONLY
            </Text>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Open Teen Patti rules and how to play"
            onPress={() => router.push('/rules')}
            style={({ pressed }) => [
              styles.headerIconButton,
              { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
            ]}
            testID="open-game-rules"
          >
            <Feather name="book-open" size={17} color={colors.primary} />
          </Pressable>
        </View>

        {storageWarning ? (
          <View style={[styles.storageWarning, { backgroundColor: colors.secondary }]}>
            <Feather name="alert-circle" size={14} color={colors.goldSoft} />
            <Text style={[styles.storageWarningText, { color: colors.secondaryForeground }]}>
              {storageWarning}
            </Text>
          </View>
        ) : null}

        <LinearGradient
          colors={[colors.heroStart, colors.heroEnd]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.table}
        >
          <View style={styles.tableTopLine}>
            <View style={[styles.tableDot, { backgroundColor: colors.success }]} />
            <Text style={[styles.tableLabel, { color: colors.goldSoft }]}>PRACTICE TABLE</Text>
            <Text style={[styles.tableStake, { color: colors.mutedForeground }]}>
              DEALER {dealerName} · ANTE {ANTE_POINTS}
            </Text>
          </View>
          <View style={styles.opponentsRow}>
            {opponents.map((player) => (
              <OpponentSeat
                key={player.id}
                player={player}
                current={currentPlayer?.id === player.id}
                revealCards={game.phase === 'round-over'}
              />
            ))}
          </View>
          <View style={[styles.potCard, { backgroundColor: colors.background }]}>
            <Text style={[styles.potLabel, { color: colors.mutedForeground }]}>
              {game.phase === 'round-over' ? 'POT AWARDED' : 'TABLE POT'}
            </Text>
            <Text style={[styles.potValue, { color: colors.cream }]}>
              {(game.phase === 'round-over'
                ? game.result?.potAwarded ?? 0
                : game.pot
              ).toLocaleString('en-IN')}
            </Text>
            <Text style={[styles.potUnit, { color: colors.goldSoft }]}>virtual points</Text>
          </View>
          <View style={styles.tableMeta}>
            <View style={[styles.metaPill, { backgroundColor: colors.accent }]}>
              <Feather name="activity" size={12} color={colors.success} />
              <Text style={[styles.metaText, { color: colors.cream }]}>
                STAKE {game.currentStake} PTS
              </Text>
            </View>
            <Text style={[styles.tableTurn, { color: colors.mutedForeground }]}>
              {humanTurn ? 'Your turn' : game.phase === 'round-over' ? 'Round complete' : `${currentPlayer?.name ?? 'Computer'} is playing`}
            </Text>
          </View>
        </LinearGradient>

        <View style={styles.handHeader}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Your hand</Text>
            <Text style={[styles.sectionCaption, { color: colors.mutedForeground }]}>
              {human.seen || game.phase === 'round-over'
                ? 'Cards revealed'
                : 'You are playing blind'}
            </Text>
          </View>
          {game.phase === 'playing' && !human.seen && !human.folded ? (
            <Pressable
              accessibilityRole="button"
              onPress={handleReveal}
              style={({ pressed }) => [
                styles.revealButton,
                { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed ? 0.75 : 1 },
              ]}
              testID="look-at-cards"
            >
              <Feather name="eye" size={14} color={colors.primary} />
              <Text style={[styles.revealLabel, { color: colors.foreground }]}>Look at cards</Text>
            </Pressable>
          ) : (
            <View style={[styles.statusChip, { backgroundColor: colors.accent }]}>
              <Text style={[styles.statusChipText, { color: colors.goldSoft }]}>
                {game.phase === 'round-over' ? 'SHOWDOWN' : 'SEEN'}
              </Text>
            </View>
          )}
        </View>

        <View style={styles.playerHand} testID="player-hand">
          {human.cards.map((card, index) => (
            <GameCard
              key={`you-${index}`}
              rank={card.rank}
              suit={card.suit}
              hidden={!human.seen && game.phase !== 'round-over'}
            />
          ))}
        </View>

        {game.phase === 'playing' ? (
          <>
            <View style={styles.turnMessage}>
              <View
                style={[
                  styles.turnIndicator,
                  { backgroundColor: humanTurn ? colors.success : colors.primary },
                ]}
              />
              <Text style={[styles.turnMessageText, { color: colors.mutedForeground }]}>
                {game.message}
              </Text>
            </View>

            {humanTurn ? (
              <View style={styles.actionArea}>
                <View style={styles.actionRow}>
                  <ActionButton
                    label="Pack"
                    detail="fold"
                    icon="x"
                    onPress={() => handleAction('fold')}
                    disabled={!humanTurn}
                    testID="action-fold"
                  />
                  <ActionButton
                    label="Chaal"
                    detail={`${callCost} pts`}
                    icon="check"
                    onPress={() => handleAction('call')}
                    disabled={!humanTurn || callCost > human.balance}
                    primary
                    testID="action-call"
                  />
                  <ActionButton
                    label="Raise"
                    detail={`to ${nextStake} stake`}
                    icon="trending-up"
                    onPress={() => handleAction('raise')}
                    disabled={
                      !humanTurn ||
                      nextStake <= game.currentStake ||
                      raiseCost > human.balance
                    }
                    testID="action-raise"
                  />
                </View>
                {showCost !== null ? (
                  <Pressable
                    accessibilityRole="button"
                    disabled={!humanTurn || showCost > human.balance}
                    onPress={() => handleAction('show')}
                    style={({ pressed }) => [
                      styles.showButton,
                      {
                        backgroundColor: colors.secondary,
                        opacity:
                          !humanTurn || showCost > human.balance
                            ? 0.4
                            : pressed
                              ? 0.78
                              : 1,
                      },
                    ]}
                    testID="action-showdown"
                  >
                    <Feather name="eye" size={15} color={colors.goldSoft} />
                    <Text style={[styles.showButtonText, { color: colors.cream }]}>
                      Showdown · {showCost} pts
                    </Text>
                  </Pressable>
                ) : null}
              </View>
            ) : (
              <View style={[styles.waitingCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="loader" size={15} color={colors.primary} />
                <Text style={[styles.waitingText, { color: colors.mutedForeground }]}>
                  Computer opponents are taking their turns…
                </Text>
              </View>
            )}
          </>
        ) : (
          <View style={[styles.resultCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View
              style={[
                styles.resultIcon,
                { backgroundColor: humanWon ? colors.accent : colors.secondary },
              ]}
            >
              <Feather
                name={humanWon ? 'award' : 'rotate-ccw'}
                size={22}
                color={humanWon ? colors.primary : colors.goldSoft}
              />
            </View>
            <Text style={[styles.resultEyebrow, { color: colors.primary }]}>ROUND RESULT</Text>
            <Text style={[styles.resultTitle, { color: colors.foreground }]}>
              {humanWon ? 'You win!' : `${winners[0]?.name ?? 'Opponent'} wins`}
            </Text>
            <Text style={[styles.resultHand, { color: colors.goldSoft }]}>
              {game.result?.winningHand ?? ''}
            </Text>
            <Text style={[styles.resultSummary, { color: colors.mutedForeground }]}>
              {game.result?.netPoints !== undefined
                ? `${game.result.netPoints > 0 ? '+' : ''}${game.result.netPoints} virtual points this round`
                : 'Practice points only'}
            </Text>
            <View style={[styles.resultDivider, { backgroundColor: colors.border }]} />
            <View style={styles.resultDetailRow}>
              <Text style={[styles.resultDetailLabel, { color: colors.mutedForeground }]}>Pot awarded</Text>
              <Text style={[styles.resultDetailValue, { color: colors.foreground }]}>
                {game.result?.potAwarded.toLocaleString('en-IN') ?? 0} pts
              </Text>
            </View>
            <View style={styles.resultDetailRow}>
              <Text style={[styles.resultDetailLabel, { color: colors.mutedForeground }]}>Your points</Text>
              <Text style={[styles.resultDetailValue, { color: colors.goldSoft }]}>
                {human.balance.toLocaleString('en-IN')} pts
              </Text>
            </View>
            <View style={styles.resultActions}>
              <Pressable
                accessibilityRole="button"
                onPress={handleNewRound}
                style={({ pressed }) => [
                  styles.newRoundButton,
                  { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
                ]}
                testID="new-round"
              >
                <Feather name="refresh-cw" size={16} color={colors.primaryForeground} />
                <Text style={[styles.newRoundText, { color: colors.primaryForeground }]}>
                  New Round
                </Text>
              </Pressable>
              <Pressable
                accessibilityRole="button"
                onPress={exitHome}
                style={({ pressed }) => [
                  styles.exitButton,
                  { borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
                ]}
                testID="result-exit-home"
              >
                <Text style={[styles.exitButtonText, { color: colors.foreground }]}>
                  Exit Home
                </Text>
              </Pressable>
            </View>
          </View>
        )}

        <View style={[styles.pointsFooter, { borderColor: colors.border }]}>
          <Feather name="shield" size={13} color={colors.success} />
          <Text style={[styles.pointsFooterText, { color: colors.mutedForeground }]}>
            Free to play · Points have no cash value
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 17, paddingTop: 9, gap: 12 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  loadingText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
  header: { minHeight: 46, flexDirection: 'row', alignItems: 'center', gap: 11 },
  headerIconButton: { width: 39, height: 39, borderRadius: 13, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  headerCopy: { flex: 1, gap: 3 },
  headerTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', letterSpacing: -0.3 },
  headerSub: { fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 0.7 },
  storageWarning: { borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 8 },
  storageWarningText: { flex: 1, fontSize: 9, fontFamily: 'Inter_500Medium', lineHeight: 14 },
  table: { minHeight: 282, borderRadius: 23, padding: 13, overflow: 'hidden' },
  tableTopLine: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  tableDot: { width: 6, height: 6, borderRadius: 4 },
  tableLabel: { flex: 1, fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 1 },
  tableStake: { fontSize: 8, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.5 },
  opponentsRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 6, marginTop: 11 },
  opponentSeat: { flex: 1, minHeight: 121, borderRadius: 13, borderWidth: 1, padding: 7, justifyContent: 'space-between' },
  opponentHeading: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  opponentAvatar: { width: 22, height: 22, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  opponentNameWrap: { flex: 1, minWidth: 0 },
  opponentName: { fontSize: 9, fontFamily: 'Inter_700Bold' },
  opponentStatus: { fontSize: 7, fontFamily: 'Inter_700Bold', letterSpacing: 0.4, marginTop: 2 },
  opponentCards: { flexDirection: 'row', justifyContent: 'center', gap: 2, marginTop: 7 },
  smallCardBack: { width: 22, height: 31, borderRadius: 5, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  smallFaceCard: { width: 22, height: 31, borderRadius: 5, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  smallRank: { fontSize: 8, lineHeight: 9, fontFamily: 'Inter_700Bold' },
  smallSuit: { fontSize: 8, lineHeight: 9, fontFamily: 'Inter_700Bold' },
  opponentBalance: { fontSize: 7, fontFamily: 'Inter_500Medium', textAlign: 'center', marginTop: 4 },
  potCard: { minHeight: 70, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginTop: 10, paddingVertical: 7 },
  potLabel: { fontSize: 7, fontFamily: 'Inter_700Bold', letterSpacing: 1.1 },
  potValue: { fontSize: 25, lineHeight: 29, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },
  potUnit: { fontSize: 8, fontFamily: 'Inter_500Medium' },
  tableMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 9 },
  metaPill: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 20, paddingHorizontal: 8, paddingVertical: 5 },
  metaText: { fontSize: 7, fontFamily: 'Inter_700Bold', letterSpacing: 0.45 },
  tableTurn: { fontSize: 9, fontFamily: 'Inter_500Medium' },
  handHeader: { minHeight: 38, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  sectionCaption: { fontSize: 9, fontFamily: 'Inter_400Regular', marginTop: 3 },
  revealButton: { minHeight: 33, borderRadius: 11, borderWidth: 1, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 6 },
  revealLabel: { fontSize: 9, fontFamily: 'Inter_600SemiBold' },
  statusChip: { borderRadius: 20, paddingHorizontal: 9, paddingVertical: 6 },
  statusChipText: { fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 0.65 },
  playerHand: { flexDirection: 'row', justifyContent: 'center', gap: 9 },
  cardBack: { width: 67, height: 92, borderRadius: 11, borderWidth: 1.3, alignItems: 'center', justifyContent: 'center' },
  faceCard: { width: 67, height: 92, borderRadius: 11, borderWidth: 1.3, padding: 7, alignItems: 'center', justifyContent: 'center', gap: 2 },
  cardRank: { fontSize: 19, lineHeight: 23, fontFamily: 'Inter_700Bold' },
  cardSuit: { fontSize: 24, lineHeight: 27, fontFamily: 'Inter_700Bold' },
  turnMessage: { flexDirection: 'row', alignItems: 'center', gap: 7, minHeight: 19 },
  turnIndicator: { width: 6, height: 6, borderRadius: 4 },
  turnMessageText: { flex: 1, fontSize: 9, fontFamily: 'Inter_500Medium', lineHeight: 14 },
  actionArea: { gap: 8 },
  actionRow: { flexDirection: 'row', gap: 7 },
  actionButton: { flex: 1, minHeight: 67, borderRadius: 14, borderWidth: 1, alignItems: 'center', justifyContent: 'center', gap: 3, paddingHorizontal: 4 },
  actionLabel: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  actionDetail: { fontSize: 8, fontFamily: 'Inter_500Medium' },
  showButton: { minHeight: 39, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  showButtonText: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  waitingCard: { minHeight: 45, borderRadius: 13, borderWidth: 1, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 9 },
  waitingText: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  resultCard: { borderRadius: 19, borderWidth: 1, padding: 16, alignItems: 'center' },
  resultIcon: { width: 45, height: 45, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  resultEyebrow: { fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 1 },
  resultTitle: { fontSize: 21, fontFamily: 'Inter_700Bold', marginTop: 4 },
  resultHand: { fontSize: 10, fontFamily: 'Inter_600SemiBold', marginTop: 4 },
  resultSummary: { fontSize: 10, fontFamily: 'Inter_500Medium', marginTop: 6 },
  resultDivider: { width: '100%', height: StyleSheet.hairlineWidth, marginVertical: 12 },
  resultDetailRow: { width: '100%', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  resultDetailLabel: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  resultDetailValue: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  resultActions: { width: '100%', gap: 8, marginTop: 7 },
  newRoundButton: { minHeight: 43, borderRadius: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  newRoundText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  exitButton: { minHeight: 39, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  exitButtonText: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  pointsFooter: { minHeight: 30, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  pointsFooterText: { fontSize: 8, fontFamily: 'Inter_500Medium' },
});
