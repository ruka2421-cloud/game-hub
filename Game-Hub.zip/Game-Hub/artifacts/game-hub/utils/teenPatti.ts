export const STARTING_POINTS = 2_500;
export const ANTE_POINTS = 10;
export const MINIMUM_STAKE = 10;
export const MAXIMUM_STAKE = 40;

export type Suit = 'Spades' | 'Hearts' | 'Diamonds' | 'Clubs';

export interface Card {
  rank: number;
  suit: Suit;
}

export interface HandValue {
  category: number;
  label: string;
  tiebreak: number[];
}

export interface GamePlayer {
  id: string;
  name: string;
  isHuman: boolean;
  dealer: boolean;
  cards: Card[];
  balance: number;
  // Total wager points added after the ante.
  contribution: number;
  folded: boolean;
  seen: boolean;
}

export interface RoundResult {
  winnerIds: string[];
  winningHand: string;
  potAwarded: number;
  netPoints: number;
}

export interface GameState {
  players: GamePlayer[];
  pot: number;
  currentStake: number;
  currentTurnIndex: number;
  phase: 'playing' | 'round-over';
  message: string;
  log: string[];
  roundNumber: number;
  startingBalance: number;
  pointsRefilled: boolean;
  result: RoundResult | null;
}

export type PlayerAction = 'fold' | 'call' | 'raise' | 'show';
export type RandomSource = () => number;

const SUITS: Suit[] = ['Spades', 'Hearts', 'Diamonds', 'Clubs'];

const RANK_NAMES: Record<number, string> = {
  11: 'J',
  12: 'Q',
  13: 'K',
  14: 'A',
};

const PLAYER_SEATS = [
  { id: 'you', name: 'You', isHuman: true },
  { id: 'bot-mira', name: 'Mira', isHuman: false },
  { id: 'bot-dev', name: 'Dev', isHuman: false },
  { id: 'bot-asha', name: 'Asha', isHuman: false },
] as const;

export function rankName(rank: number): string {
  return RANK_NAMES[rank] ?? String(rank);
}

export function suitSymbol(suit: Suit): string {
  switch (suit) {
    case 'Spades':
      return '♠';
    case 'Hearts':
      return '♥';
    case 'Diamonds':
      return '♦';
    case 'Clubs':
      return '♣';
  }
}

export function createDeck(): Card[] {
  return SUITS.flatMap((suit) =>
    Array.from({ length: 13 }, (_, index) => ({
      rank: index + 2,
      suit,
    })),
  );
}

export function shuffleDeck(deck: Card[], random: RandomSource = Math.random): Card[] {
  const shuffled = [...deck];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const sample = random();
    const normalized = Number.isFinite(sample)
      ? Math.min(0.999999999, Math.max(0, sample))
      : 0.5;
    const swapIndex = Math.floor(normalized * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

function isSequence(ranks: number[]): { isSequence: boolean; high: number } {
  const descending = [...ranks].sort((left, right) => right - left);
  if (descending[0] === 14 && descending[1] === 3 && descending[2] === 2) {
    return { isSequence: true, high: 14 };
  }

  const consecutive =
    descending[0] - descending[1] === 1 && descending[1] - descending[2] === 1;
  if (!consecutive) return { isSequence: false, high: 0 };

  // A-K-Q is highest, followed by A-2-3, then K-Q-J and the remaining runs.
  const high = descending[0] === 14 && descending[1] === 13 ? 15 : descending[0];
  return { isSequence: true, high };
}

export function evaluateHand(cards: Card[]): HandValue {
  if (cards.length !== 3) {
    throw new Error('Teen Patti hands must contain exactly three cards.');
  }
  if (
    cards.some(
      (card) =>
        !Number.isInteger(card.rank) ||
        card.rank < 2 ||
        card.rank > 14 ||
        !SUITS.includes(card.suit),
    )
  ) {
    throw new Error('Teen Patti cards must use ranks 2 through Ace and a standard suit.');
  }
  const cardKeys = cards.map((card) => `${card.rank}:${card.suit}`);
  if (new Set(cardKeys).size !== 3) {
    throw new Error('A Teen Patti hand cannot contain duplicate cards.');
  }

  const ranks = cards.map((card) => card.rank).sort((left, right) => right - left);
  const sameSuit = cards.every((card) => card.suit === cards[0]?.suit);
  const counts = new Map<number, number>();
  for (const rank of ranks) counts.set(rank, (counts.get(rank) ?? 0) + 1);

  const trailRank = [...counts.entries()].find(([, count]) => count === 3)?.[0];
  if (trailRank !== undefined) {
    return { category: 6, label: 'Trail / Three of a Kind', tiebreak: [trailRank] };
  }

  const sequence = isSequence(ranks);
  if (sequence.isSequence && sameSuit) {
    return { category: 5, label: 'Pure Sequence', tiebreak: [sequence.high] };
  }
  if (sequence.isSequence) {
    return { category: 4, label: 'Sequence', tiebreak: [sequence.high] };
  }
  if (sameSuit) {
    return { category: 3, label: 'Color / Flush', tiebreak: ranks };
  }

  const pairRank = [...counts.entries()].find(([, count]) => count === 2)?.[0];
  if (pairRank !== undefined) {
    const kicker = ranks.find((rank) => rank !== pairRank) ?? 0;
    return { category: 2, label: 'Pair', tiebreak: [pairRank, kicker] };
  }

  return { category: 1, label: 'High Card', tiebreak: ranks };
}

export function compareHands(left: Card[], right: Card[]): number {
  const leftValue = evaluateHand(left);
  const rightValue = evaluateHand(right);
  if (leftValue.category !== rightValue.category) {
    return leftValue.category > rightValue.category ? 1 : -1;
  }

  const maxLength = Math.max(leftValue.tiebreak.length, rightValue.tiebreak.length);
  for (let index = 0; index < maxLength; index += 1) {
    const leftValueAtIndex = leftValue.tiebreak[index] ?? 0;
    const rightValueAtIndex = rightValue.tiebreak[index] ?? 0;
    if (leftValueAtIndex !== rightValueAtIndex) {
      return leftValueAtIndex > rightValueAtIndex ? 1 : -1;
    }
  }

  // Suits do not break a tie; the show rule determines the winner of equal hands.
  return 0;
}

export function getChaalCost(player: GamePlayer, currentStake: number): number {
  return currentStake * (player.seen ? 2 : 1);
}

export function getNextStake(currentStake: number): number {
  return Math.min(currentStake * 2, MAXIMUM_STAKE);
}

export function getRaiseCost(player: GamePlayer, currentStake: number): number | null {
  const nextStake = getNextStake(currentStake);
  if (nextStake <= currentStake) return null;
  return nextStake * (player.seen ? 2 : 1);
}

export function getShowCost(
  requester: GamePlayer,
  opponent: GamePlayer,
  currentStake: number,
): number | null {
  // Common table rule: a blind player may request a show at the current stake.
  // A seen player may request one only against another seen player, at 2x stake.
  if (requester.seen && !opponent.seen) return null;
  return currentStake * (requester.seen ? 2 : 1);
}

export function createRound(
  availablePoints: number,
  roundNumber: number,
  random: RandomSource = Math.random,
): GameState {
  const safeAvailablePoints =
    Number.isFinite(availablePoints) && availablePoints >= 0
      ? Math.floor(availablePoints)
      : STARTING_POINTS;
  const pointsRefilled = safeAvailablePoints < ANTE_POINTS;
  const startingBalance = pointsRefilled ? STARTING_POINTS : safeAvailablePoints;
  const safeRoundNumber =
    Number.isInteger(roundNumber) && roundNumber > 0 ? roundNumber : 1;
  const deck = shuffleDeck(createDeck(), random);
  const hands: Card[][] = PLAYER_SEATS.map(() => []);
  // Deal one card to each seat in order, three times around the table.
  for (let pass = 0; pass < 3; pass += 1) {
    for (let playerIndex = 0; playerIndex < PLAYER_SEATS.length; playerIndex += 1) {
      const card = deck[pass * PLAYER_SEATS.length + playerIndex];
      if (card) hands[playerIndex]?.push(card);
    }
  }
  const dealerIndex = (safeRoundNumber - 1) % PLAYER_SEATS.length;
  const players: GamePlayer[] = PLAYER_SEATS.map((seat, index) => ({
    ...seat,
    dealer: index === dealerIndex,
    cards: hands[index] ?? [],
    balance: (seat.isHuman ? startingBalance : STARTING_POINTS) - ANTE_POINTS,
    contribution: 0,
    folded: false,
    // The bots can choose to play blind or seen. The human starts blind and may
    // freely look at their cards before or during their turn.
    seen: seat.isHuman ? false : random() < 0.45,
  }));
  const firstPlayerIndex = (dealerIndex + 1) % players.length;
  const firstPlayerName = players[firstPlayerIndex]?.name ?? 'The next player';
  const message = pointsRefilled
    ? `Free practice points refreshed. ${firstPlayerName} acts first.`
    : `${firstPlayerName} acts first. Players act clockwise from the dealer.`;

  return {
    players,
    pot: ANTE_POINTS * players.length,
    currentStake: MINIMUM_STAKE,
    currentTurnIndex: firstPlayerIndex,
    phase: 'playing',
    message,
    log: [
      `Everyone put ${ANTE_POINTS} virtual points into the pot.`,
      `Dealer: ${players[dealerIndex]?.name ?? 'Unknown'}.`,
    ],
    roundNumber: safeRoundNumber,
    startingBalance,
    pointsRefilled,
    result: null,
  };
}

export function getActivePlayers(state: GameState): GamePlayer[] {
  return state.players.filter((player) => !player.folded);
}

function getPlayerIndex(state: GameState, id: string): number {
  return state.players.findIndex((player) => player.id === id);
}

function addLog(state: GameState, entry: string): string[] {
  return [...state.log, entry].slice(-5);
}
function finishRound(
  state: GameState,
  winnerId: string,
  winningHand: string,
  message: string,
): GameState {
  const winner = state.players.find(
    (player) => player.id === winnerId && !player.folded,
  );
  if (!winner) return state;
  const updatedPlayers = state.players.map((player) => {
    return player.id === winnerId
      ? { ...player, balance: player.balance + state.pot }
      : player;
  });
  const human = updatedPlayers.find((player) => player.isHuman);
  const result: RoundResult = {
    winnerIds: [winnerId],
    winningHand,
    potAwarded: state.pot,
    netPoints: (human?.balance ?? 0) - state.startingBalance,
  };

  return {
    ...state,
    players: updatedPlayers,
    pot: 0,
    phase: 'round-over',
    currentTurnIndex: -1,
    message,
    log: addLog(state, message),
    result,
  };
}

function advanceAfterAction(
  state: GameState,
  actorIndex: number,
  message: string,
): GameState {
  const active = getActivePlayers(state);
  if (active.length === 0) {
    throw new Error('A Teen Patti round cannot continue without an active player.');
  }
  if (active.length === 1) {
    const winner = active[0];
    if (!winner) return state;
    const winningHand = evaluateHand(winner.cards).label;
    return finishRound(
      state,
      winner.id,
      winningHand,
      `${winner.name} wins the pot. The other players folded.`,
    );
  }

  let nextIndex = actorIndex;
  for (let step = 0; step < state.players.length; step += 1) {
    nextIndex = (nextIndex + 1) % state.players.length;
    if (!state.players[nextIndex]?.folded) break;
  }

  return {
    ...state,
    currentTurnIndex: nextIndex,
    message,
    log: addLog(state, message),
  };
}

function payPoints(
  state: GameState,
  playerIndex: number,
  amount: number,
): GameState | null {
  const player = state.players[playerIndex];
  if (!player || amount < 0 || amount > player.balance) return null;
  const players = [...state.players];
  players[playerIndex] = {
    ...player,
    balance: player.balance - amount,
    contribution: player.contribution + amount,
  };
  return { ...state, players, pot: state.pot + amount };
}

function settleShowdown(state: GameState, actorIndex: number): GameState {
  const active = getActivePlayers(state);
  if (active.length !== 2) return state;
  const actor = state.players[actorIndex];
  const opponent = active.find((player) => player.id !== actor?.id);
  if (!actor || !opponent) return state;

  const showCost = getShowCost(actor, opponent, state.currentStake);
  if (showCost === null) return state;
  const updated = payPoints(state, actorIndex, showCost);
  if (!updated) return state;

  const comparison = compareHands(actor.cards, opponent.cards);
  // Under the common show rule, the player who requests a show loses an exact tie.
  const winner = comparison > 0 ? actor : opponent;
  const winningHand = evaluateHand(winner.cards).label;
  return finishRound(
    updated,
    winner.id,
    winningHand,
    comparison === 0
      ? `${winner.name} wins the tie; the player who requested the show loses.`
      : `${winner.name} wins the showdown with ${winningHand}.`,
  );
}

function performAction(
  state: GameState,
  actorIndex: number,
  action: PlayerAction,
): GameState {
  if (state.phase !== 'playing') return state;
  const actor = state.players[actorIndex];
  if (!actor || actor.folded) return state;

  if (action === 'show') {
    return settleShowdown(state, actorIndex);
  }

  if (action === 'fold') {
    if (getActivePlayers(state).length <= 1) return state;
    const players = [...state.players];
    players[actorIndex] = { ...actor, folded: true };
    const updated = { ...state, players };
    return advanceAfterAction(updated, actorIndex, `${actor.name} packs.`);
  }

  if (action === 'call') {
    const cost = getChaalCost(actor, state.currentStake);
    const updated = payPoints(state, actorIndex, cost);
    if (!updated) return state;
    return advanceAfterAction(
      updated,
      actorIndex,
      `${actor.name} ${actor.seen ? 'plays seen' : 'plays blind'} and adds ${cost} points.`,
    );
  }

  const newStake = getNextStake(state.currentStake);
  const cost = getRaiseCost(actor, state.currentStake);
  if (cost === null) return state;
  const updated = payPoints(state, actorIndex, cost);
  if (!updated) return state;
  const raised = { ...updated, currentStake: newStake };
  return advanceAfterAction(
    raised,
    actorIndex,
    `${actor.name} raises the stake to ${newStake} points.`,
  );
}

export function applyHumanAction(
  state: GameState,
  action: PlayerAction,
  _random: RandomSource = Math.random,
): GameState {
  const currentPlayer = state.players[state.currentTurnIndex];
  if (!currentPlayer?.isHuman || state.phase !== 'playing') return state;
  return performAction(state, state.currentTurnIndex, action);
}

function chooseComputerAction(state: GameState, player: GamePlayer, random: RandomSource): PlayerAction {
  const hand = evaluateHand(player.cards);
  const cost = getChaalCost(player, state.currentStake);
  const activePlayers = getActivePlayers(state);

  if (cost > player.balance) return 'fold';

  let foldChance = 0.04;
  if (hand.category === 1) {
    const topCard = Math.max(...hand.tiebreak);
    foldChance = state.currentStake >= 30 ? 0.72 : topCard < 10 ? 0.45 : 0.22;
  } else if (hand.category === 2) {
    foldChance = state.currentStake >= 30 ? 0.28 : 0.1;
  } else if (hand.category === 3) {
    foldChance = state.currentStake >= 30 ? 0.12 : 0.035;
  }
  if (random() < foldChance) return 'fold';

  if (activePlayers.length === 2) {
    const opponent = activePlayers.find((activePlayer) => activePlayer.id !== player.id);
    const showCost = opponent
      ? getShowCost(player, opponent, state.currentStake)
      : null;
    if (
      showCost !== null &&
      showCost <= player.balance &&
      random() < (hand.category >= 3 ? 0.28 : 0.12)
    ) {
      return 'show';
    }
  }

  if (
    state.currentStake < MAXIMUM_STAKE &&
    hand.category >= 3 &&
    random() < (hand.category >= 5 ? 0.38 : 0.2)
  ) {
    const raiseCost = getRaiseCost(player, state.currentStake);
    if (raiseCost !== null && raiseCost <= player.balance) return 'raise';
  }

  return 'call';
}

export function playComputerTurn(
  state: GameState,
  random: RandomSource = Math.random,
): GameState {
  if (state.phase !== 'playing') return state;
  const player = state.players[state.currentTurnIndex];
  if (!player || player.isHuman || player.folded) return state;
  return performAction(
    state,
    state.currentTurnIndex,
    chooseComputerAction(state, player, random),
  );
}

export function revealHumanCards(state: GameState): GameState {
  const humanIndex = getPlayerIndex(state, 'you');
  const human = state.players[humanIndex];
  if (!human || human.seen || human.folded || state.phase !== 'playing') return state;
  const players = [...state.players];
  players[humanIndex] = { ...human, seen: true };
  return {
    ...state,
    players,
    message:
      state.currentTurnIndex === humanIndex
        ? 'Your cards are open. A seen call costs twice the current stake.'
        : `${human.name} looked at their cards.`,
  };
}

export function getCurrentHuman(state: GameState): GamePlayer | undefined {
  return state.players.find((player) => player.isHuman);
}

export function getWinners(state: GameState): GamePlayer[] {
  if (!state.result) return [];
  return state.result.winnerIds
    .map((id) => state.players.find((player) => player.id === id))
    .filter((player): player is GamePlayer => player !== undefined);
}

