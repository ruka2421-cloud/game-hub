export type RummySuit = 'Spades' | 'Hearts' | 'Diamonds' | 'Clubs';
export type RummySource = 'stock' | 'discard';
export type RummyPhase = 'draw' | 'discard' | 'round-over';
export type MeldKind = 'sequence' | 'set';

export interface RummyCard {
  id: string;
  rank: number | null;
  suit: RummySuit | null;
  printedJoker: boolean;
  deck: number;
}

export interface RummyPlayer {
  id: string;
  name: string;
  isHuman: boolean;
  hand: RummyCard[];
  totalPenalty: number;
}

export interface RummySubstitution {
  cardId: string;
  rank: number;
  suit: RummySuit;
}

export interface RummyMeld {
  kind: MeldKind;
  pure: boolean;
  cards: RummyCard[];
  substitutions: RummySubstitution[];
}

export interface RummyValidation {
  valid: boolean;
  reason: string | null;
  groups: RummyMeld[];
}

export interface RummyScore {
  penalty: number;
  hasPureSequence: boolean;
  hasTwoSequences: boolean;
}

export interface RummyDiscardChoice {
  cardId: string;
  canDeclare: boolean;
  penalty: number;
}

export interface RummyRoundScore {
  playerId: string;
  roundPenalty: number;
  totalPenalty: number;
}

export interface RummyResult {
  winnerId: string;
  scores: RummyRoundScore[];
  winningGroups: RummyMeld[];
}

export interface RummyGameState {
  players: RummyPlayer[];
  drawPile: RummyCard[];
  discardPile: RummyCard[];
  wildRank: number | null;
  wildMarker: RummyCard;
  currentPlayerIndex: number;
  phase: RummyPhase;
  drawnCardId: string | null;
  drawnFrom: RummySource | null;
  selectedDiscardId: string | null;
  roundNumber: number;
  message: string;
  log: string[];
  result: RummyResult | null;
}

export type RandomSource = () => number;

const SUITS: RummySuit[] = ['Spades', 'Hearts', 'Diamonds', 'Clubs'];
const PLAYER_NAMES = ['You', 'Mira', 'Dev', 'Asha'];
const MAX_PENALTY = 80;
const FULL_DECKS = 2;

interface MeldOption {
  mask: number;
  kind: MeldKind;
  pure: boolean;
  substitutions: RummySubstitution[];
}

function normalizedRandom(random: RandomSource): number {
  const sample = random();
  return Number.isFinite(sample) ? Math.min(0.999999999, Math.max(0, sample)) : 0.5;
}

export function shuffleRummyCards(
  cards: RummyCard[],
  random: RandomSource = Math.random,
): RummyCard[] {
  const shuffled = [...cards];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(normalizedRandom(random) * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex]!, shuffled[index]!];
  }
  return shuffled;
}

export function createRummyDeck(): RummyCard[] {
  const cards: RummyCard[] = [];
  for (let deck = 0; deck < FULL_DECKS; deck += 1) {
    for (const suit of SUITS) {
      for (let rank = 2; rank <= 14; rank += 1) {
        cards.push({
          id: `deck-${deck}-${suit}-${rank}`,
          rank,
          suit,
          printedJoker: false,
          deck,
        });
      }
    }
    cards.push({
      id: `deck-${deck}-printed-joker`,
      rank: null,
      suit: null,
      printedJoker: true,
      deck,
    });
  }
  return cards;
}

export function createRummyGame(
  playerCount = 4,
  random: RandomSource = Math.random,
  cumulativePenalties: Record<string, number> = {},
  roundNumber = 1,
): RummyGameState {
  if (!Number.isInteger(playerCount) || playerCount < 2 || playerCount > 4) {
    throw new RangeError('Indian Rummy supports 2 to 4 players in Game Hub.');
  }

  const shuffled = shuffleRummyCards(createRummyDeck(), random);
  const wildMarkerIndex = shuffled.findIndex((card) => !card.printedJoker);
  const [wildMarker] = shuffled.splice(wildMarkerIndex, 1);
  if (!wildMarker) throw new Error('Could not choose a wild-joker marker.');

  const players: RummyPlayer[] = Array.from({ length: playerCount }, (_, index) => ({
    id: index === 0 ? 'you' : `bot-${index}`,
    name: PLAYER_NAMES[index] ?? `Player ${index + 1}`,
    isHuman: index === 0,
    hand: [],
    totalPenalty: Math.max(
      0,
      Math.floor(cumulativePenalties[index === 0 ? 'you' : `bot-${index}`] ?? 0),
    ),
  }));

  for (let pass = 0; pass < 13; pass += 1) {
    for (const player of players) {
      const card = shuffled.pop();
      if (!card) throw new Error('The deck ran out while dealing.');
      player.hand.push(card);
    }
  }

  const firstDiscard = shuffled.pop();
  if (!firstDiscard) throw new Error('The deck ran out while setting up the discard pile.');

  return {
    players,
    drawPile: shuffled,
    discardPile: [firstDiscard],
    wildRank: wildMarker.rank,
    wildMarker,
    currentPlayerIndex: 0,
    phase: 'draw',
    drawnCardId: null,
    drawnFrom: null,
    selectedDiscardId: null,
    roundNumber: Math.max(1, Math.floor(roundNumber)),
    message: 'Your turn. Draw from the stock or take the top discard.',
    log: [`${players.length} players received 13 cards each.`],
    result: null,
  };
}

export function rankName(rank: number | null): string {
  if (rank === null) return 'Joker';
  return ({ 11: 'J', 12: 'Q', 13: 'K', 14: 'A' } as Record<number, string>)[rank] ?? String(rank);
}

export function suitSymbol(suit: RummySuit | null): string {
  switch (suit) {
    case 'Spades':
      return '♠';
    case 'Hearts':
      return '♥';
    case 'Diamonds':
      return '♦';
    case 'Clubs':
      return '♣';
    default:
      return '★';
  }
}

export function rummyMeldLabel(group: Pick<RummyMeld, 'kind' | 'pure'>): string {
  if (group.kind === 'set') return 'Set';
  return group.pure ? 'Pure Sequence' : 'Impure Sequence';
}

export function formatRummyMeldCard(
  card: RummyCard,
  substitutions: RummySubstitution[],
): string {
  const physical = `${rankName(card.rank)}${suitSymbol(card.suit)}`;
  const substitution = substitutions.find((item) => item.cardId === card.id);
  if (!substitution) return physical;
  return `${physical} → ${rankName(substitution.rank)}${suitSymbol(substitution.suit)} (wild)`;
}

export function isWildCard(card: RummyCard, wildRank: number | null): boolean {
  return card.printedJoker || (wildRank !== null && card.rank === wildRank);
}

export function cardPointValue(card: RummyCard, wildRank: number | null): number {
  if (isWildCard(card, wildRank)) return 0;
  if (card.rank === null) return 0;
  if (card.rank >= 10) return 10;
  return card.rank;
}

function isValidCard(card: RummyCard): boolean {
  if (!card || typeof card.id !== 'string' || card.id.length === 0) return false;
  if (card.printedJoker) return card.rank === null && card.suit === null;
  return (
    Number.isInteger(card.rank) &&
    (card.rank ?? 0) >= 2 &&
    (card.rank ?? 0) <= 14 &&
    SUITS.includes(card.suit as RummySuit)
  );
}

function sequenceOrders(): number[][] {
  const aceHigh = Array.from({ length: 13 }, (_, index) => index + 2);
  const aceLow = [14, ...Array.from({ length: 12 }, (_, index) => index + 2)];
  return [aceHigh, aceLow];
}

function buildMeldOptions(cards: RummyCard[], wildRank: number | null): MeldOption[] {
  const options = new Map<string, MeldOption>();
  const wildIndices = cards
    .map((card, index) => (isWildCard(card, wildRank) ? index : -1))
    .filter((index) => index >= 0);

  const addOption = (
    indices: number[],
    kind: MeldKind,
    pure: boolean,
    substitutions: RummySubstitution[],
  ) => {
    const mask = indices.reduce((value, index) => value | (1 << index), 0);
    const substitutionKey = substitutions
      .map((item) => `${item.cardId}:${item.rank}:${item.suit}`)
      .sort()
      .join(',');
    const key = `${mask}:${kind}:${pure ? 1 : 0}:${substitutionKey}`;
    if (!options.has(key)) options.set(key, { mask, kind, pure, substitutions });
  };

  const generateSlots = (
    slotMatches: number[][],
    targets: Array<{ rank: number; suit: RummySuit }>,
    kind: MeldKind,
    allowNaturalWild: boolean,
  ) => {
    const used = new Set<number>();
    const selected: number[] = [];
    const substitutions: RummySubstitution[] = [];

    const visit = (slotIndex: number, usedSubstitution: boolean) => {
      if (slotIndex === slotMatches.length) {
        addOption(
          selected,
          kind,
          kind === 'sequence' && !usedSubstitution,
          [...substitutions],
        );
        return;
      }

      for (const cardIndex of slotMatches[slotIndex] ?? []) {
        if (used.has(cardIndex)) continue;
        used.add(cardIndex);
        selected.push(cardIndex);
        visit(slotIndex + 1, usedSubstitution);
        selected.pop();
        used.delete(cardIndex);
      }

      for (const cardIndex of wildIndices) {
        if (used.has(cardIndex)) continue;
        const card = cards[cardIndex];
        const target = targets[slotIndex];
        if (
          !card ||
          !target ||
          (allowNaturalWild && slotMatches[slotIndex]?.includes(cardIndex))
        ) {
          continue;
        }
        used.add(cardIndex);
        selected.push(cardIndex);
        substitutions.push({
          cardId: card.id,
          rank: target.rank,
          suit: target.suit,
        });
        visit(slotIndex + 1, true);
        substitutions.pop();
        selected.pop();
        used.delete(cardIndex);
      }
    };

    visit(0, false);
  };

  // Ace can be low (A-2-3...) or high (...Q-K-A), never both in one sequence.
  for (const suit of SUITS) {
    for (const order of sequenceOrders()) {
      for (let length = 3; length <= order.length; length += 1) {
        for (let start = 0; start + length <= order.length; start += 1) {
          const ranks = order.slice(start, start + length);
          const targets = ranks.map((rank) => ({ rank, suit }));
          const slotMatches = ranks.map((rank) =>
            cards
              .map((card, index) =>
                card.rank === rank && card.suit === suit ? index : -1,
              )
              .filter((index) => index >= 0),
          );
          generateSlots(slotMatches, targets, 'sequence', true);
        }
      }
    }
  }

  // A set has one card per represented suit; a wild card may stand for a missing suit.
  for (let rank = 2; rank <= 14; rank += 1) {
    for (let suitMask = 0; suitMask < 1 << SUITS.length; suitMask += 1) {
      const targets = SUITS.filter(
        (_suit, suitIndex) => ((suitMask >> suitIndex) & 1) === 1,
      ).map((suit) => ({ rank, suit }));
      if (targets.length < 3) continue;
      const slotMatches = targets.map(({ rank: targetRank, suit }) =>
        cards
          .map((card, index) =>
            card.rank === targetRank && card.suit === suit ? index : -1,
          )
          .filter((index) => index >= 0),
      );
      generateSlots(slotMatches, targets, 'set', false);
    }
  }

  return [...options.values()];
}

function groupForOption(option: MeldOption, cards: RummyCard[]): RummyMeld {
  return {
    kind: option.kind,
    pure: option.pure,
    cards: cards.filter((_card, index) => (option.mask & (1 << index)) !== 0),
    substitutions: option.substitutions,
  };
}

export function validateRummyMeld(
  cards: RummyCard[],
  wildRank: number | null,
): RummyValidation {
  if (!Array.isArray(cards) || cards.length < 3) {
    return { valid: false, reason: 'A meld needs at least 3 cards.', groups: [] };
  }
  if (
    (wildRank !== null && (!Number.isInteger(wildRank) || wildRank < 2 || wildRank > 14)) ||
    cards.some((card) => !isValidCard(card)) ||
    new Set(cards.map((card) => card.id)).size !== cards.length
  ) {
    return { valid: false, reason: 'This meld contains an invalid or repeated card.', groups: [] };
  }
  const fullMask = (1 << cards.length) - 1;
  const option = buildMeldOptions(cards, wildRank).find((item) => item.mask === fullMask);
  if (!option) {
    return {
      valid: false,
      reason: 'Cards do not form a valid same-suit sequence or different-suit set.',
      groups: [],
    };
  }
  return { valid: true, reason: null, groups: [groupForOption(option, cards)] };
}

export function validateRummyHand(
  cards: RummyCard[],
  wildRank: number | null,
): RummyValidation {
  if (!Array.isArray(cards) || cards.length !== 13) {
    return { valid: false, reason: 'A declaration must arrange exactly 13 cards.', groups: [] };
  }
  if (
    (wildRank !== null && (!Number.isInteger(wildRank) || wildRank < 2 || wildRank > 14)) ||
    cards.some((card) => !isValidCard(card)) ||
    new Set(cards.map((card) => card.id)).size !== cards.length
  ) {
    return { valid: false, reason: 'This hand contains an invalid or repeated card.', groups: [] };
  }

  const options = buildMeldOptions(cards, wildRank);
  const byCard = Array.from({ length: cards.length }, () => [] as MeldOption[]);
  for (const option of options) {
    for (let index = 0; index < cards.length; index += 1) {
      if ((option.mask & (1 << index)) !== 0) byCard[index]?.push(option);
    }
  }

  const fullMask = (1 << cards.length) - 1;
  const memo = new Map<string, RummyMeld[] | null>();
  const solve = (
    remaining: number,
    sequenceCount: number,
    hasPureSequence: boolean,
  ): RummyMeld[] | null => {
    if (remaining === 0) {
      return sequenceCount >= 2 && hasPureSequence ? [] : null;
    }
    const key = `${remaining}:${sequenceCount}:${hasPureSequence ? 1 : 0}`;
    if (memo.has(key)) return memo.get(key) ?? null;

    let firstIndex = 0;
    while ((remaining & (1 << firstIndex)) === 0) firstIndex += 1;
    for (const option of byCard[firstIndex] ?? []) {
      if ((option.mask & remaining) !== option.mask) continue;
      const tail = solve(
        remaining ^ option.mask,
        Math.min(2, sequenceCount + (option.kind === 'sequence' ? 1 : 0)),
        hasPureSequence || option.pure,
      );
      if (tail) {
        const arrangement = [groupForOption(option, cards), ...tail];
        memo.set(key, arrangement);
        return arrangement;
      }
    }
    memo.set(key, null);
    return null;
  };

  const groups = solve(fullMask, 0, false);
  if (groups) return { valid: true, reason: null, groups };

  const hasPure = options.some((option) => option.kind === 'sequence' && option.pure);
  const sequenceOptions = options.filter((option) => option.kind === 'sequence');
  if (!hasPure) {
    return {
      valid: false,
      reason: 'A pure sequence is required. A wild-rank card used as itself may be pure; a joker substitution is not.',
      groups: [],
    };
  }
  if (sequenceOptions.length < 2) {
    return { valid: false, reason: 'At least two sequences are required.', groups: [] };
  }
  return {
    valid: false,
    reason: 'All 13 cards must fit into non-overlapping valid sequences or sets.',
    groups: [],
  };
}

export function scoreRummyHand(
  cards: RummyCard[],
  wildRank: number | null,
): RummyScore {
  const safeCards = Array.isArray(cards) ? cards.filter(isValidCard) : [];
  const total = Math.min(
    MAX_PENALTY,
    safeCards.reduce((sum, card) => sum + cardPointValue(card, wildRank), 0),
  );
  if (safeCards.length !== 13 || new Set(safeCards.map((card) => card.id)).size !== safeCards.length) {
    return { penalty: MAX_PENALTY, hasPureSequence: false, hasTwoSequences: false };
  }

  const options = buildMeldOptions(safeCards, wildRank);
  const pureOptions = options.filter((option) => option.kind === 'sequence' && option.pure);
  const sequenceOptions = options.filter((option) => option.kind === 'sequence');
  if (pureOptions.length === 0 || sequenceOptions.length < 2) {
    return {
      penalty: total,
      hasPureSequence: pureOptions.length > 0,
      hasTwoSequences: sequenceOptions.length > 1,
    };
  }

  const byCard = Array.from({ length: safeCards.length }, () => [] as MeldOption[]);
  for (const option of options) {
    for (let index = 0; index < safeCards.length; index += 1) {
      if ((option.mask & (1 << index)) !== 0) byCard[index]?.push(option);
    }
  }
  const fullMask = (1 << safeCards.length) - 1;
  const memo = new Map<string, number>();
  const solve = (remaining: number, sequenceCount: number, hasPure: boolean): number => {
    if (remaining === 0) {
      return sequenceCount >= 2 && hasPure ? 0 : Number.POSITIVE_INFINITY;
    }
    const key = `${remaining}:${sequenceCount}:${hasPure ? 1 : 0}`;
    const cached = memo.get(key);
    if (cached !== undefined) return cached;

    let firstIndex = 0;
    while ((remaining & (1 << firstIndex)) === 0) firstIndex += 1;
    let best =
      cardPointValue(safeCards[firstIndex]!, wildRank) +
      solve(remaining ^ (1 << firstIndex), sequenceCount, hasPure);
    for (const option of byCard[firstIndex] ?? []) {
      if ((option.mask & remaining) !== option.mask) continue;
      best = Math.min(
        best,
        solve(
          remaining ^ option.mask,
          Math.min(2, sequenceCount + (option.kind === 'sequence' ? 1 : 0)),
          hasPure || option.pure,
        ),
      );
    }
    memo.set(key, best);
    return best;
  };

  const penalty = solve(fullMask, 0, false);
  return {
    penalty: Number.isFinite(penalty) ? Math.min(MAX_PENALTY, penalty) : total,
    hasPureSequence: true,
    hasTwoSequences: true,
  };
}

export function getBestDiscard(
  cards: RummyCard[],
  wildRank: number | null,
  forbiddenCardId: string | null = null,
): RummyDiscardChoice | null {
  if (cards.length !== 14) return null;
  const candidates = cards.filter((card) => card.id !== forbiddenCardId);
  if (candidates.length === 0) return null;

  let best: RummyDiscardChoice | null = null;
  for (const discard of candidates) {
    const hand = cards.filter((card) => card.id !== discard.id);
    const validation = validateRummyHand(hand, wildRank);
    const penalty = validation.valid ? 0 : scoreRummyHand(hand, wildRank).penalty;
    const candidate = { cardId: discard.id, canDeclare: validation.valid, penalty };
    if (
      best === null ||
      (candidate.canDeclare && !best.canDeclare) ||
      (candidate.canDeclare === best.canDeclare &&
        (candidate.penalty < best.penalty ||
          (candidate.penalty === best.penalty &&
            cardPointValue(discard, wildRank) > cardPointValue(cards.find((card) => card.id === best?.cardId)!, wildRank))))
    ) {
      best = candidate;
    }
  }
  return best;
}

function addLog(state: RummyGameState, entry: string): string[] {
  return [...state.log, entry].slice(-6);
}

function shuffledDiscardForStock(
  state: RummyGameState,
  random: RandomSource,
): RummyGameState {
  if (state.drawPile.length > 0 || state.discardPile.length < 2) return state;
  const top = state.discardPile[state.discardPile.length - 1];
  if (!top) return state;
  const recycled = shuffleRummyCards(state.discardPile.slice(0, -1), random);
  return { ...state, drawPile: recycled, discardPile: [top] };
}

function drawCardForPlayer(
  state: RummyGameState,
  playerIndex: number,
  source: RummySource,
  random: RandomSource,
): RummyGameState {
  if (state.phase !== 'draw' || state.result) return state;
  const player = state.players[playerIndex];
  if (!player || playerIndex !== state.currentPlayerIndex) return state;

  let prepared = source === 'stock' ? shuffledDiscardForStock(state, random) : state;
  let card: RummyCard | undefined;
  if (source === 'discard') {
    card = prepared.discardPile[prepared.discardPile.length - 1];
    if (!card) {
      return { ...prepared, message: 'There is no card on the discard pile to take.' };
    }
    prepared = { ...prepared, discardPile: prepared.discardPile.slice(0, -1) };
  } else {
    card = prepared.drawPile[prepared.drawPile.length - 1];
    if (!card) {
      return { ...prepared, message: 'The stock is empty. Take the top discard instead.' };
    }
    prepared = { ...prepared, drawPile: prepared.drawPile.slice(0, -1) };
  }

  const players = [...prepared.players];
  players[playerIndex] = { ...player, hand: [...player.hand, card] };
  const sourceLabel = source === 'stock' ? 'stock' : 'discard pile';
  return {
    ...prepared,
    players,
    phase: 'discard',
    drawnCardId: card.id,
    drawnFrom: source,
    selectedDiscardId: null,
    message: `${player.name} drew from the ${sourceLabel}. Choose a card to discard.`,
    log: addLog(prepared, `${player.name} drew from the ${sourceLabel}.`),
  };
}

function finishRummyRound(state: RummyGameState, winnerId: string): RummyGameState {
  const winner = state.players.find((player) => player.id === winnerId);
  if (!winner) return state;
  const scoreRows: RummyRoundScore[] = state.players.map((player) => {
    const roundPenalty =
      player.id === winnerId ? 0 : scoreRummyHand(player.hand, state.wildRank).penalty;
    return {
      playerId: player.id,
      roundPenalty,
      totalPenalty: player.totalPenalty + roundPenalty,
    };
  });
  const scoreById = new Map(scoreRows.map((score) => [score.playerId, score]));
  const players = state.players.map((player) => ({
    ...player,
    totalPenalty: scoreById.get(player.id)?.totalPenalty ?? player.totalPenalty,
  }));
  const message = `${winner.name} declared a valid hand and wins this round.`;
  const winningGroups = validateRummyHand(winner.hand, state.wildRank).groups;
  return {
    ...state,
    players,
    phase: 'round-over',
    currentPlayerIndex: -1,
    selectedDiscardId: null,
    message,
    log: addLog(state, message),
    result: { winnerId, scores: scoreRows, winningGroups },
  };
}

function completeDiscard(
  state: RummyGameState,
  playerIndex: number,
  cardId: string,
  declare: boolean,
): RummyGameState {
  if (state.phase !== 'discard' || state.result || playerIndex !== state.currentPlayerIndex) {
    return state;
  }
  const player = state.players[playerIndex];
  if (!player) return state;
  if (cardId === state.drawnCardId && state.drawnFrom === 'discard') {
    return { ...state, message: 'You cannot discard the card you just took from the discard pile.' };
  }
  if (!player.hand.some((card) => card.id === cardId)) {
    return { ...state, message: 'Select a card in your hand to discard.' };
  }

  const remainingHand = player.hand.filter((card) => card.id !== cardId);
  if (remainingHand.length !== 13) return state;
  const validation = validateRummyHand(remainingHand, state.wildRank);
  if (declare && !validation.valid) {
    return {
      ...state,
      selectedDiscardId: cardId,
      message: validation.reason ?? 'That hand does not meet the declaration rules.',
    };
  }

  if (declare) {
    const players = [...state.players];
    players[playerIndex] = { ...player, hand: remainingHand };
    return finishRummyRound(
      {
        ...state,
        players,
        discardPile: [...state.discardPile, player.hand.find((card) => card.id === cardId)!],
        log: addLog(state, `${player.name} discarded and declared.`),
      },
      player.id,
    );
  }

  const discarded = player.hand.find((card) => card.id === cardId)!;
  const players = [...state.players];
  players[playerIndex] = { ...player, hand: remainingHand };
  const nextPlayerIndex = (playerIndex + 1) % players.length;
  const nextPlayer = players[nextPlayerIndex];
  const message =
    nextPlayer?.isHuman
      ? 'Your turn. Draw from the stock or take the top discard.'
      : `${nextPlayer?.name ?? 'The next player'} is thinking.`;
  return {
    ...state,
    players,
    discardPile: [...state.discardPile, discarded],
    currentPlayerIndex: nextPlayerIndex,
    phase: 'draw',
    drawnCardId: null,
    drawnFrom: null,
    selectedDiscardId: null,
    message,
    log: addLog(state, `${player.name} discarded ${rankName(discarded.rank)}${suitSymbol(discarded.suit)}.`),
  };
}

export function drawForHuman(
  state: RummyGameState,
  source: RummySource,
  random: RandomSource = Math.random,
): RummyGameState {
  const player = state.players[state.currentPlayerIndex];
  if (!player?.isHuman || state.phase !== 'draw') return state;
  return drawCardForPlayer(state, state.currentPlayerIndex, source, random);
}

export function selectRummyDiscard(
  state: RummyGameState,
  cardId: string,
): RummyGameState {
  const player = state.players[state.currentPlayerIndex];
  if (!player?.isHuman || state.phase !== 'discard') return state;
  if (!player.hand.some((card) => card.id === cardId)) return state;
  return { ...state, selectedDiscardId: cardId };
}

export function discardForHuman(
  state: RummyGameState,
  declare = false,
  cardId = state.selectedDiscardId,
): RummyGameState {
  const player = state.players[state.currentPlayerIndex];
  if (!player?.isHuman || !cardId) return state;
  return completeDiscard(state, state.currentPlayerIndex, cardId, declare);
}

function chooseComputerSource(
  state: RummyGameState,
  player: RummyPlayer,
  random: RandomSource,
): RummySource {
  if (state.discardPile.length === 0) return 'stock';
  if (state.drawPile.length === 0 && state.discardPile.length === 1) return 'discard';

  const topDiscard = state.discardPile[state.discardPile.length - 1];
  if (!topDiscard) return 'stock';
  const baseline = scoreRummyHand(player.hand, state.wildRank).penalty;
  const hypothetical = getBestDiscard(
    [...player.hand, topDiscard],
    state.wildRank,
    topDiscard.id,
  );
  if (!hypothetical) return 'stock';
  if (hypothetical.canDeclare || hypothetical.penalty <= baseline - 4) return 'discard';
  return random() < 0.2 ? 'discard' : 'stock';
}

export function playComputerTurn(
  state: RummyGameState,
  random: RandomSource = Math.random,
): RummyGameState {
  if (state.phase !== 'draw' || state.result) return state;
  const player = state.players[state.currentPlayerIndex];
  if (!player || player.isHuman) return state;

  const source = chooseComputerSource(state, player, random);
  const drawn = drawCardForPlayer(state, state.currentPlayerIndex, source, random);
  if (drawn.phase !== 'discard') return drawn;
  const currentPlayer = drawn.players[drawn.currentPlayerIndex];
  if (!currentPlayer) return drawn;
  const choice = getBestDiscard(
    currentPlayer.hand,
    drawn.wildRank,
    drawn.drawnFrom === 'discard' ? drawn.drawnCardId : null,
  );
  if (!choice) {
    return { ...drawn, message: `${currentPlayer.name} could not choose a legal discard.` };
  }
  return completeDiscard(drawn, drawn.currentPlayerIndex, choice.cardId, choice.canDeclare);
}

export function createNextRummyRound(
  previous: RummyGameState,
  random: RandomSource = Math.random,
): RummyGameState {
  const scores = Object.fromEntries(
    previous.players.map((player) => [player.id, player.totalPenalty]),
  );
  return createRummyGame(previous.players.length, random, scores, previous.roundNumber + 1);
}

