/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#F2E8D5',
    tint: '#D4AE62',

    // Core surfaces
    background: '#0B1D17',
    foreground: '#F2E8D5',

    // Cards / elevated surfaces
    card: '#122B22',
    cardForeground: '#F2E8D5',

    // Primary action color (buttons, links, active states)
    primary: '#D4AE62',
    primaryForeground: '#17251B',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#18382C',
    secondaryForeground: '#E8D8B8',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#19352B',
    mutedForeground: '#9AAE9F',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#264838',
    accentForeground: '#F2E8D5',

    // Destructive actions (delete, error states)
    destructive: '#DB7565',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#254638',
    input: '#315545',

    // Game Hub brand accents
    heroStart: '#1B4836',
    heroEnd: '#102A21',
    goldSoft: '#E7CA8E',
    cream: '#F6EEDC',
    success: '#82B49A',
  },
  dark: {
    text: '#F2E8D5',
    tint: '#D4AE62',
    background: '#0B1D17',
    foreground: '#F2E8D5',
    card: '#122B22',
    cardForeground: '#F2E8D5',
    primary: '#D4AE62',
    primaryForeground: '#17251B',
    secondary: '#18382C',
    secondaryForeground: '#E8D8B8',
    muted: '#19352B',
    mutedForeground: '#9AAE9F',
    accent: '#264838',
    accentForeground: '#F2E8D5',
    destructive: '#DB7565',
    destructiveForeground: '#FFFFFF',
    border: '#254638',
    input: '#315545',
    heroStart: '#1B4836',
    heroEnd: '#102A21',
    goldSoft: '#E7CA8E',
    cream: '#F6EEDC',
    success: '#82B49A',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 18,
};

export default colors;
