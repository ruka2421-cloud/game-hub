import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { STARTING_POINTS } from '@/utils/teenPatti';

const STORAGE_KEY = 'game-hub-virtual-points-v1';

interface VirtualPointsValue {
  balance: number;
  isLoaded: boolean;
  storageWarning: string | null;
  saveBalance: (nextBalance: number) => Promise<void>;
}

const VirtualPointsContext = createContext<VirtualPointsValue | null>(null);

export function VirtualPointsProvider({ children }: { children: ReactNode }) {
  const [balance, setBalance] = useState(STARTING_POINTS);
  const [isLoaded, setIsLoaded] = useState(false);
  const [storageWarning, setStorageWarning] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const loadPoints = async () => {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEY);
        const parsed = saved === null ? STARTING_POINTS : Number.parseInt(saved, 10);
        const safeBalance =
          Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : STARTING_POINTS;
        if (saved === null) {
          await AsyncStorage.setItem(STORAGE_KEY, String(safeBalance));
        }
        if (active) setBalance(safeBalance);
      } catch {
        if (active) {
          setStorageWarning('Points could not be loaded from this device. This session will still work.');
        }
      } finally {
        if (active) setIsLoaded(true);
      }
    };
    void loadPoints();
    return () => {
      active = false;
    };
  }, []);

  const saveBalance = useCallback(async (nextBalance: number) => {
    const safeBalance = Math.max(0, Math.floor(nextBalance));
    setBalance(safeBalance);
    try {
      await AsyncStorage.setItem(STORAGE_KEY, String(safeBalance));
      setStorageWarning(null);
    } catch {
      setStorageWarning('Points could not be saved on this device. They remain available for this session.');
    }
  }, []);

  const value = useMemo(
    () => ({ balance, isLoaded, storageWarning, saveBalance }),
    [balance, isLoaded, storageWarning, saveBalance],
  );

  return (
    <VirtualPointsContext.Provider value={value}>
      {children}
    </VirtualPointsContext.Provider>
  );
}

export function useVirtualPoints(): VirtualPointsValue {
  const context = useContext(VirtualPointsContext);
  if (!context) {
    throw new Error('useVirtualPoints must be used inside VirtualPointsProvider.');
  }
  return context;
}
